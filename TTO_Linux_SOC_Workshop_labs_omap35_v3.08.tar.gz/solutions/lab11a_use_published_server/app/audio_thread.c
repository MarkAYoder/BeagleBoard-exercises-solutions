/*
 *   audio_thread.c
 */

/* Standard Linux headers */
#include <stdio.h>                               // always include stdio.h
#include <stdlib.h>                              // always include stdlib.h
#include <string.h>                              // defines memset and memcpy methods

/* Codec Engine headers */
#include <xdc/std.h>                             // xdc definitions. Must come 1st
#include <ti/sdo/ce/Engine.h>                    // Required for any CE application

/* DMAI headers */
#include <ti/sdo/dmai/Dmai.h>
#include <ti/sdo/dmai/Sound.h>
#include <ti/sdo/dmai/Buffer.h>
#include <ti/sdo/dmai/ce/Adec.h>
#include <ti/sdo/dmai/ce/Aenc.h>

/* Application header files */
#include "debug.h"                               // DBG and ERR macros
#include "audio_thread.h"                        // Audio thread definitions

/* Audio encoder and decoder names */
#define AUDIO_DECODER       "auddec_copy"
#define AUDIO_ENCODER       "audenc_copy"

/* The sample rate of the audio codec.*/
#define SAMPLE_RATE 44100

/* The gain (0-100) of the left channel.*/
#define LEFT_GAIN 100

/* The gain (0-100) of the right channel.*/
#define RIGHT_GAIN 100

/*  Parameters for audio thread execution */
#define BLOCKSIZE 4096


/*************************************************************************
 * audio_thread_fxn                                                      *
 *************************************************************************/
/*  input parameters:                                                    */
/*      void *envByRef       --  pointer to audio_thread_env structure   */
/*                               as defined in audio_thread.h            */
/*                                                                       */
/*          envByRef.quit    -- when quit != 0, thread will exit         */
/*          env->engineName -- string value specifying name of           */
/*                              engine configuration for Engine_open     */
/*                                                                       */
/*  return value:                                                        */
/*      void *     --  AUDIO_THREAD_SUCCESS or AUDIO_THREAD_FAILURE as   */
/*                     defined in audio_thread.h                         */
/*************************************************************************/
void *audio_thread_fxn(void *envByRef)
{
/*  Thread parameters and return value */
    audio_thread_env *env = envByRef;                   // see above
    void    	     *status = AUDIO_THREAD_SUCCESS;	// see above


/*  The levels of initialization for initMask */
#define ALSA_INITIALIZED        0x1
#define INPUT_BUFFER_ALLOCATED  0x2
#define OUTPUT_BUFFER_ALLOCATED 0x4
#define AUDIOENCODERCREATED     0x8
#define AUDIODECODERCREATED     0x10
#define ENCODEDBUFFERALLOCATED  0x20
#define ENGINEOPENED		    0x40
    unsigned int initMask = 0x0;            // Used to only cleanup items that were init'ed

/*  Codec engine variables */
    Engine_Handle engineHandle       = NULL;                // handle to the engine
    Aenc_Handle encoderHandle        = NULL;                // handle to audio encoder 
    Adec_Handle decoderHandle        = NULL;                // handle to audio decoder
    AUDENC_Params aeParams           = Aenc_Params_DEFAULT;
    AUDDEC_Params adParams           = Adec_Params_DEFAULT;
    AUDENC_DynamicParams aeDynParams = Aenc_DynamicParams_DEFAULT;
    AUDDEC_DynamicParams adDynParams = Adec_DynamicParams_DEFAULT;

/*  Input and output buffer variables  */
    int blksize = BLOCKSIZE;

    Buffer_Attrs bAttrs   = Buffer_Attrs_DEFAULT;
    Sound_Attrs  sAttrs   = Sound_Attrs_STEREO_DEFAULT;

    Buffer_Handle hBufIn  = NULL, hBufOut = NULL, hBufEnc = NULL;
    Sound_Handle hSound   = NULL;


/* Thread Create Phase -- secure and initialize resources */

    system("amixer cset name='Analog Left AUXL Capture Switch' 1");
    system("amixer cset name='Analog Right AUXR Capture Switch' 1");

    /* Initialize sound device */
    sAttrs.channels   = 2;
    sAttrs.mode       = Sound_Mode_FULLDUPLEX;
    sAttrs.soundInput = Sound_Input_LINE;
    sAttrs.sampleRate = 44100;
    sAttrs.soundStd   = Sound_Std_ALSA;
    sAttrs.bufSize    = 4096;

    hSound = Sound_create( &sAttrs );
    if( hSound==NULL )
    {
        ERR( "Failed to obtain handle to sound object\n" );
        status = AUDIO_THREAD_FAILURE;
        goto cleanup;
    }

    /* Record that input ALSA device was opened in initialization bitmask */
    initMask |= ALSA_INITIALIZED;

    /* Create input read buffer */
    hBufIn = Buffer_create( blksize, &bAttrs );
    if( hBufIn == NULL )
    {
        ERR( "Failed to allocate memory for input block (%d)\n", blksize );
        status = AUDIO_THREAD_FAILURE;
        goto cleanup;
    }

    DBG( "Allocated input audio buffer of size %d\n", blksize );

    /* Record that the output buffer was allocated in bitmask */
    initMask |= INPUT_BUFFER_ALLOCATED;

/* Open the Codec Engine */
    // Note: Codec engine should be opened in each thread that uses it
    engineHandle = Engine_open( env->engineName, NULL, NULL );

    if( engineHandle == NULL )
    {
        ERR( "Engine_setup failed in audio_thread_fxn\n" );
        status = AUDIO_THREAD_FAILURE;
        goto cleanup;
    }

    // DBG( "Engine opened in audio thread\n" );
 
    initMask |= ENGINEOPENED;

    /* Allocate and initialize audio encoder on the engine */
    /*     uses engineHandle global variable assumed set before entry */

    encoderHandle = Aenc_create( engineHandle, 
                                 AUDIO_ENCODER, 
                                 &aeParams,
                                 &aeDynParams );
    if( encoderHandle == NULL )
    {
        ERR( "Audio_encoder create failed in audio_thread_fxn\n" );
        status = AUDIO_THREAD_FAILURE;
        goto cleanup;
    }

    initMask |= AUDIOENCODERCREATED;

    /* Allocate and initialize audio decoder on the engine */

    decoderHandle = Adec_create( engineHandle, 
                                 AUDIO_DECODER, 
                                 &adParams,
                                 &adDynParams );

    if(decoderHandle == NULL)
    {
        ERR( "Audio_decoder create failed in audio_thread_fxn\n" );
        status = AUDIO_THREAD_FAILURE;
        goto cleanup;
    }

    initMask |= AUDIODECODERCREATED;


    /* Initialize the output audio buffer */

    hBufOut = Buffer_create( blksize, &bAttrs );
    if( hBufOut == NULL )
    {
        ERR( "Failed to allocate memory for output audio buffer (%d)\n", blksize );
        status = AUDIO_THREAD_FAILURE;
        goto cleanup;
    }

    DBG( "Allocated output audio buffer of size %d\n", blksize );

    /* Record that the output buffer was allocated in bitmask */
    initMask |= OUTPUT_BUFFER_ALLOCATED;

    /*  Create encoded buffer to store encoded audio */
    /*  To be safe, encoded buffer is the same size as raw buffer */
    hBufEnc = Buffer_create( blksize, &bAttrs );
	
    if( hBufEnc == NULL )
    {
        ERR( "Failed to allocate memory for encoded block (%d)\n", blksize );
        status = AUDIO_THREAD_FAILURE;
        goto cleanup;
    }

    initMask |= ENCODEDBUFFERALLOCATED;

    DBG( "Allocated intermediate audio buffer of size %d\n", blksize );


/* Prime the pump */

    Buffer_setNumBytesUsed( hBufIn, Buffer_getSize( hBufIn ) );
	if( Sound_read( hSound, hBufIn ) < 0 ) 
    {
        ERR( "Sound_read failed in audio_thread_fxn\n" );
        status = AUDIO_THREAD_FAILURE;
        goto cleanup;
    }

   Buffer_setNumBytesUsed( hBufIn, Buffer_getSize( hBufIn ) );
   Sound_write( hSound, hBufIn );

   Buffer_setNumBytesUsed( hBufIn, Buffer_getSize( hBufIn ) );
   Sound_write( hSound, hBufIn );


/* Thread Execute Phase -- perform I/O and processing */

    DBG( "Entering audio_thread_fxn processing loop\n" );
    while ( !env->quit )
    {
        /*  Read input buffer from ALSA input device */
        if( Sound_read( hSound, hBufIn ) < 0 )
        {
            ERR( "Sound_read failed in audio_thread_fxn\n" );
            status = AUDIO_THREAD_FAILURE;
            break;
        }


        /* Encode the buffer */

        if ( Aenc_process( encoderHandle, hBufIn, hBufEnc ) < 0 ) 
        {
            ERR( "Error encoding audio data \n" );
            status = AUDIO_THREAD_FAILURE;
            break;
        }

        /* Decode the buffer */ 

	// Workaround for copy codec not filling in bytes consumed
	Buffer_setNumBytesUsed( hBufEnc, Buffer_getSize( hBufEnc ) );

        if ( Adec_process( decoderHandle, hBufEnc, hBufOut ) < 0 ) 
        {
            ERR( "Error decoding audio data \n" );
            status = AUDIO_THREAD_FAILURE;
            break;
        }

        /* Write output buffer into ALSA output device */

        // Workaround for copy codec not filling in bytes consumed
        Buffer_setNumBytesUsed( hBufOut, Buffer_getSize( hBufOut ) );

        Sound_write( hSound, hBufOut );
    }


cleanup:
    /* Thread Delete Phase -- free resources no longer needed by thread */

    DBG("Exited audio_thread_fxn processing loop\n");
    DBG("\tStarting audio thread cleanup to return resources to system\n");

    /* Use the initMask to only free resources that were allocated     */
    /* Nothing to be done for mixer device, it was closed after init   */

    /* Note the ALSA output device must be closed before anything else */
    /*      if this driver expends it's backlog of data before it is   */
    /*      closed, it will lock up the application.                   */


    /* Free output buffer */
    if( initMask & OUTPUT_BUFFER_ALLOCATED )
    {
        Buffer_delete( hBufOut );
    }

    /* Close ALSA device */
    if( initMask & ALSA_INITIALIZED )
        Sound_delete( hSound );

    /* Delete audio decoder */
    if ( initMask & AUDIODECODERCREATED )
        Adec_delete( decoderHandle );

    /* Delete audio encoder */
    if ( initMask & AUDIOENCODERCREATED ) 
        Aenc_delete( encoderHandle );

    /* Close the engine */
    if ( initMask & ENGINEOPENED )
    {
        Engine_close( engineHandle );
    }

    /* Free input buffer */
    if( initMask & INPUT_BUFFER_ALLOCATED )
    {
        Buffer_delete( hBufIn );
    }

    /* Free intermediate (encoded) buffer */
    if ( initMask & ENCODEDBUFFERALLOCATED ) 
    {
        Buffer_delete( hBufEnc );
    }

    /* Return the status of the thread execution */
    DBG( "\tAudio thread cleanup complete. Exiting audio_thread_fxn\n" );
    return status;
}


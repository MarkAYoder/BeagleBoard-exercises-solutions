
/*
 *  ======== mixer.c ========
 *  Universal algorithm.
 *
 *  This file contains an implementation of the IUNIVERSAL interface
 *  defined by XDM.
 */
#include <xdc/std.h>
#include <string.h>

#include <ti/xdais/dm/iuniversal.h>

#ifdef __TI_COMPILER_VERSION__
/* XDAIS Rule 13 - this #pragma should only apply to TI codegen */
#pragma CODE_SECTION(MIXER_TTO_control, ".text:algControl")
#pragma CODE_SECTION(MIXER_TTO_process, ".text:algProcess")
#pragma CODE_SECTION(MIXER_TTO_initObj, ".text:algInit")
#pragma CODE_SECTION(MIXER_TTO_free,    ".text:algFree")
#pragma CODE_SECTION(MIXER_TTO_alloc,   ".text:algAlloc")
#endif

#include "mixer_tto.h"
#include "mixer_tto_priv.h"

#define MIXER_VERSIONSTRING "1.00.00.00"

/* Helper definitions */
#define BITSPERBYTE     8       /* number of bits in a byte */

/* buffer definitions */
#define MININBUFS       1
#define MINOUTBUFS      1
#define MININBUFSIZE    1
#define MINOUTBUFSIZE   1

#define IALGFXNS  \
    &MIXER_TTO_IALG,/* module ID */                        \
    NULL,               /* activate */                          \
    MIXER_TTO_alloc,/* alloc */                            \
    NULL,               /* control (NULL => no control ops) */  \
    NULL,               /* deactivate */                        \
    MIXER_TTO_free, /* free */                             \
    MIXER_TTO_initObj, /* init */                          \
    NULL,               /* moved */                             \
    NULL                /* numAlloc (NULL => IALG_MAXMEMRECS) */

/*
 *  ======== MIXER_TTO_IMIXER ========
 *  This structure defines TTO's implementation of the IUNIVERSAL interface
 *  for the MIXER_TTO module.
 */
IUNIVERSAL_Fxns MIXER_TTO_IMIXER = {
    {IALGFXNS},
    MIXER_TTO_process,
    MIXER_TTO_control,
};

/*
 *  ======== MIXER_TTO_IALG ========
 *  This structure defines TTO's implementation of the IALG interface
 *  for the MIXER_TTO module.
 */
#ifdef __TI_COMPILER_VERSION__
/* satisfy XDAIS symbol requirement without any overhead */
#if defined(__TI_ELFABI__) || defined(__TI_EABI_SUPPORT__)

/* Symbol doesn't have any leading underscores */
asm("MIXER_TTO_IALG .set MIXER_TTO_IMIXER");

#else

/* Symbol has a single leading underscore */
asm("_MIXER_TTO_IALG .set _MIXER_TTO_IMIXER");

#endif
#else

/*
 *  We duplicate the structure here to allow this code to be compiled and
 *  run using non-TI toolchains at the expense of unnecessary data space
 *  consumed by the definition below.
 */
IALG_Fxns MIXER_TTO_IALG = {      /* module_vendor_interface */
    IALGFXNS
};

#endif

const IMIXER_Params IMIXER_PARAMS = {
    sizeof(IUNIVERSAL_Params),       /* size */
};

/*
 *  ======== MIXER_TTO_alloc ========
 *  Return a table of memory descriptors that describe the memory needed
 *  to construct our object.
 */
/* ARGSUSED - this line tells the TI compiler not to warn about unused args. */
Int MIXER_TTO_alloc(const IALG_Params *algParams,
    IALG_Fxns **pf, IALG_MemRec memTab[])
{
    /*
     * algParams contains create params.  Sometimes the amount of memory
     * required is based on these create params - if that's the case for
     * your algorithm, you can uncomment the following line and reflect
     * on those create params to construct your memTab.
     */
//    const IMIXER_Params *params = (IMIXER_Params *)algParams;

    /* Request memory for my object */
    memTab[0].size = sizeof(MIXER_TTO_Obj);
    memTab[0].alignment = 0;
    memTab[0].space = IALG_EXTERNAL;
    memTab[0].attrs = IALG_PERSIST;

    return (1);
}


/*
 *  ======== MIXER_TTO_free ========
 *  Return a table of memory pointers that should be freed.  Note
 *  that this should include *all* memory requested in the
 *  alloc operation above.
 */
/* ARGSUSED - this line tells the TI compiler not to warn about unused args. */
Int MIXER_TTO_free(IALG_Handle handle, IALG_MemRec memTab[])
{
    /*
     * If the memory requested in algAlloc() doesn't depend on create
     * params, you can just leverage the algAlloc() call with default
     * (NULL) create params.
     */
    return (MIXER_TTO_alloc(NULL, NULL, memTab));

    /*
     * Note, however, that if the memory requested in algAlloc() is a
     * function of create params, you'll need to implement this function
     * differently.
     */
}


/*
 *  ======== MIXER_TTO_initObj ========
 *  Initialize the memory allocated on our behalf (including our object).
 */
/* ARGSUSED - this line tells the TI compiler not to warn about unused args. */
Int MIXER_TTO_initObj(IALG_Handle handle, const IALG_MemRec memTab[],
        IALG_Handle parent, const IALG_Params *algParams)
{
    const IMIXER_Params *params = (IMIXER_Params *)algParams;

    /*
     * Typically, your algorithm will store instance-specific details
     * in the object handle.  If you want to do this, uncomment the
     * following line and the 'obj' var will point at your instance object.
     */
//    MIXER_TTO_Obj *obj = (MIXER_TTO_Obj *)handle;


    /*
     * If no creation params were provided, use our algorithm-specific ones.
     * Note that these default values _should_ be documented in your algorithm
     * documentation so users know what to expect.
     */
    if (params == NULL) {
        params = &IMIXER_PARAMS;
    }

    /* Store any instance-specific details here, using the 'obj' var above */

    return (IALG_EOK);
}


/*
 *  ======== MIXER_TTO_process ========
 */
/* ARGSUSED - this line tells the TI compiler not to warn about unused args. */
XDAS_Int32 MIXER_TTO_process(IUNIVERSAL_Handle h,
        XDM1_BufDesc *inBufs, XDM1_BufDesc *outBufs, XDM1_BufDesc *inOutBufs,
        IUNIVERSAL_InArgs *universalInArgs,
        IUNIVERSAL_OutArgs *universalOutArgs)
{
    XDAS_Int32 numInBytes, i;
    XDAS_Int16 *pIn0, *pIn1, *pOut, gain0, gain1;

    /* Local casted variables to ease operating on our extended fields */
    IMIXER_InArgs *inArgs = (IMIXER_InArgs *)universalInArgs;
    IMIXER_OutArgs *outArgs = (IMIXER_OutArgs *)universalOutArgs;

    /*
     * Note that the rest of this function will be algorithm-specific.  In
     * the initial generated implementation, this process() function simply
     * copies the first inBuf to the first outBuf.  But you should modify
     * this to suit your algorithm's needs.
     */

    /*
     * Validate arguments.  You should add your own algorithm-specific
     * parameter validation and potentially algorithm-specific return values.
     */
    if ((inArgs->base.size != sizeof(*inArgs)) ||
            (outArgs->base.size != sizeof(*outArgs))) {
        outArgs->base.extendedError = XDM_UNSUPPORTEDPARAM;

        return (IUNIVERSAL_EUNSUPPORTED);
    }

    /* validate that there's 2 inBufs and 1 outBuf */
    if ((inBufs->numBufs != 2) || (outBufs->numBufs != 1)) {
        outArgs->base.extendedError = XDM_UNSUPPORTEDPARAM;

        return (IUNIVERSAL_EFAIL);
    }

    /* validate that buffer sizes are the same */
    if (inBufs->descs[0].bufSize != inBufs->descs[1].bufSize)
    	return IUNIVERSAL_EFAIL;
    if (inBufs->descs[0].bufSize != outBufs->descs[0].bufSize)
    	return IUNIVERSAL_EFAIL;

    // DO IT!
    pIn0 = (XDAS_Int16*)inBufs->descs[0].buf;
    pIn1 = (XDAS_Int16*)inBufs->descs[1].buf;
    pOut = (XDAS_Int16*)outBufs->descs[0].buf;
    gain0 = inArgs->gain0;
    gain1 = inArgs->gain1;
    numInBytes = inBufs->descs[0].bufSize;

    for(i=0; i<numInBytes/2; i++)
    {
    	pOut[i] = (pIn0[i]*(XDAS_Int32)gain0 + pIn1[i]*(XDAS_Int32)gain1) >> 15;
    }

    /* report how we accessed the input buffers */
    inBufs->descs[0].accessMask = 0;
    XDM_SETACCESSMODE_READ(inBufs->descs[0].accessMask);
    inBufs->descs[1].accessMask = 0;
    XDM_SETACCESSMODE_READ(inBufs->descs[1].accessMask);

    /* report how we accessed the output buffer */
    outBufs->descs[0].accessMask = 0;
    XDM_SETACCESSMODE_WRITE(outBufs->descs[0].accessMask);

    /*
     * Fill out the rest of the outArgs struct, including any extended
     * outArgs your algorithm has defined.
     */
    outArgs->base.extendedError = 0;

    return (IUNIVERSAL_EOK);
}


/*
 *  ======== MIXER_TTO_control ========
 */
/* ARGSUSED - this line tells the TI compiler not to warn about unused args. */
XDAS_Int32 MIXER_TTO_control(IUNIVERSAL_Handle handle,
    IUNIVERSAL_Cmd id, IUNIVERSAL_DynamicParams *universalDynParams,
    IUNIVERSAL_Status *universalStatus)
{
    XDAS_Int32 retVal;

    /* Local casted variables to ease operating on our extended fields */
    IMIXER_DynamicParams *dynParams =
            (IMIXER_DynamicParams *)universalDynParams;
    IMIXER_Status *status = (IMIXER_Status *)universalStatus;

    /* validate arguments - this codec only supports "base" XDM. */
    if ((dynParams->base.size != sizeof(*dynParams)) ||
            (status->base.size != sizeof(*status))) {

        return (IUNIVERSAL_EUNSUPPORTED);
    }

    /* initialize for the general case where we don't access the data buffer */
    XDM_CLEARACCESSMODE_READ(status->base.data.descs[0].accessMask);
    XDM_CLEARACCESSMODE_WRITE(status->base.data.descs[0].accessMask);

    switch (id) {
         case XDM_GETVERSION:
 //           if ((status->base.data.descs[0].buf != NULL) &&
 //               (status->base.data.descs[0].bufSize >=
//                    strlen(MIXER_VERSIONSTRING))) {

                strncpy((char *)status->base.data.descs[0].buf,
                        MIXER_VERSIONSTRING,
                        strlen(MIXER_VERSIONSTRING));

                /* null terminate the string */
                status->base.data.descs[0].
                    buf[strlen(MIXER_VERSIONSTRING)] = '\0';

                /* strncpy wrote to the data buffer */
                XDM_SETACCESSMODE_WRITE(status->base.data.descs[0].accessMask);

                retVal = IUNIVERSAL_EOK;
//            }
 //           else {
 //               retVal = IUNIVERSAL_EFAIL;
 //           }

            break;

#if 0
        /*
         * If you defined any custom commands, you can check for them
         * here and handle them accordingly.
         */
        case IMIXER_USERCMD0:
            /* ... */
            break;

        case IMIXER_USERCMD1:
            /* ... */
            break;
#endif

        default:
            /* unsupported cmd */
            retVal = IUNIVERSAL_EFAIL;

            break;
    }

    return (retVal);
}


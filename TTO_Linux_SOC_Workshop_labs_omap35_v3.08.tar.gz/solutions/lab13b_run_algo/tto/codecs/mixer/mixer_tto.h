/*
 *  ======== mixer_tto.h ========
 */

#ifndef MIXER_TTO_IMIXER_
#define MIXER_TTO_IMIXER_

#include <ti/xdais/ialg.h>
#include <ti/xdais/dm/iuniversal.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== MIXER_TTO_IMIXER ========
 *  Our implementation of the IUNIVERSAL interface
 */
extern IUNIVERSAL_Fxns MIXER_TTO_IMIXER;
extern IALG_Fxns MIXER_TTO_IALG;

/*
 * You can optionally define algorithm-specific command IDs to send
 * in the control() call.  You can define these by enabling the
 * following code.  Feel free to change the "USERCMDX" to something
 * meaningful to users of this algorithm.
 */
#if 0
#define IMIXER_USERCMD0 (XDM_CUSTOMCMDBASE + 0)
#define IMIXER_USERCMD1 (XDM_CUSTOMCMDBASE + 1)
#endif


/*
 *  ======== IMIXER_Params ========
 */
typedef struct IMIXER_Params {
    /* This must be the first field */
    IALG_Params base;

    /* ... add any extended fields here ... */
} IMIXER_Params;

/*
 *  ======== IMIXER_PARAMS ========
 *  Default creation parameters.  Though not required, it is
 *  often a good practice to provide default create params for
 *  users of your algorithm.
 */
extern const IMIXER_Params IMIXER_PARAMS;

/*
 *  ======== IMIXER_InArgs ========
 */
typedef struct IMIXER_InArgs {
    /* This must be the first field */
    IUNIVERSAL_InArgs base;
    XDAS_Int16 gain0;
    XDAS_Int16 gain1;
    /* ... add any extended fields here ... */
} IMIXER_InArgs;

/*
 *  ======== IMIXER_OutArgs ========
 */
typedef struct IMIXER_OutArgs {
    /* This must be the first field */
    IUNIVERSAL_OutArgs base;

    /* ... add any extended fields here ... */
} IMIXER_OutArgs;

/*
 *  ======== IMIXER_DynamicParams ========
 */
typedef struct IMIXER_DynamicParams {
    /* This must be the first field */
    IUNIVERSAL_DynamicParams base;

    /* ... add any extended fields here ... */
} IMIXER_DynamicParams;

/*
 *  ======== IMIXER_Status ========
 */
typedef struct IMIXER_Status {
    /* This must be the first field */
    IUNIVERSAL_Status base;

    /* ... add any extended fields here ... */
} IMIXER_Status;

#ifdef __cplusplus
}
#endif

#endif

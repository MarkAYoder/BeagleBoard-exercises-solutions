/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-v48
 */

#ifndef tto_codecs_mixer__
#define tto_codecs_mixer__



#endif /* tto_codecs_mixer__ */ 

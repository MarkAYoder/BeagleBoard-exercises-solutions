/*
 *  ======== mixer_tto_priv.h ========
 *  Internal vendor specific (TTO) interface header for MIXER
 *  algorithm. Only the implementation source files include
 *  this header; this header is not shipped as part of the
 *  algorithm.
 *
 *  This header contains declarations that are specific to
 *  this implementation and which do not need to be exposed
 *  in order for an application to use the MIXER algorithm.
 */

#ifndef MIXER_TTO_IMIXER_PRIV_
#define MIXER_TTO_IMIXER_PRIV_

#include <ti/xdais/ialg.h>
#include <ti/xdais/dm/iuniversal.h>

#ifdef __cplusplus
extern "C" {
#endif


typedef struct MIXER_TTO_Obj {
    IALG_Obj    alg;            /* MUST be first field of all XDAIS algs */

    /* ... add object properties you want to store as fields here ... */
} MIXER_TTO_Obj;

extern Int MIXER_TTO_alloc(const IALG_Params *algParams,
        IALG_Fxns **pf, IALG_MemRec memTab[]);

extern Int MIXER_TTO_free(IALG_Handle handle, IALG_MemRec memTab[]);

extern Int MIXER_TTO_initObj(IALG_Handle handle,
        const IALG_MemRec memTab[], IALG_Handle parent,
        const IALG_Params *algParams);

extern XDAS_Int32 MIXER_TTO_process(IUNIVERSAL_Handle h,
        XDM1_BufDesc *inBufs, XDM1_BufDesc *outBufs, XDM1_BufDesc *inOutBufs,
        IUNIVERSAL_InArgs *inArgs, IUNIVERSAL_OutArgs *outArgs);

extern XDAS_Int32 MIXER_TTO_control(IUNIVERSAL_Handle handle,
        IUNIVERSAL_Cmd id, IUNIVERSAL_DynamicParams *params,
        IUNIVERSAL_Status *status);

#ifdef __cplusplus
}
#endif

#endif

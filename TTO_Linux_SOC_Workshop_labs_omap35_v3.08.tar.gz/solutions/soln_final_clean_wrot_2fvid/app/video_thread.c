/*
 * video_thread.c
 */

/* Standard Linux headers */
#include <stdio.h>		// always include stdio.h
#include <stdlib.h>		// always include stdlib.h
#include <string.h>             // defines memset and memcpy methods

/* dmai headers */
#include <ti/sdo/dmai/ce/Vdec.h>
#include <ti/sdo/dmai/ce/Venc.h>
#include <ti/sdo/dmai/Dmai.h>
#include <ti/sdo/dmai/Capture.h>
#include <ti/sdo/dmai/Display.h>
#include <ti/sdo/dmai/Buffer.h>
#include <ti/sdo/dmai/BufferGfx.h>

/* Application header files */
#include "debug.h"		// DBG and ERR macros
#include "video_thread.h"	// video thread definitions

/* Video encoder and decoder used */
#define VIDEO_ENCODER "videnc_copy"
#define VIDEO_DECODER "viddec_copy"

/* Align buffers to this cache line size (in bytes)*/
#define BUFSIZEALIGN            128

/* Macro for clearing structures */
#define CLEAR(x) memset (&(x), 0, sizeof (x))


#define NUM_CAPTURE_BUFS 3
#define NUM_DISPLAY_BUFS 2
#define NUM_DECODER_BUFS 3


/***************************************************************************
 * video_thread_fxn
 **************************************************************************/
/*  input parameters:                                                     */
/*      void *arg  --  a pointer to a video_thread_env structure as       */
/*                     defined in video_thread.h                          */
/*                                                                        */
/*          arg.quit    -- when quit != 0, thread will cleanup and exit   */
/*          arg.engineName -- string value specifying the codec engine    */
/*                            configuration for Engine_open               */
/*                                                                        */
/*  return value:                                                         */
/*      void *     --  VIDEO_THREAD_SUCCESS or VIDEO_THREAD_FAILURE as    */
/*                     defined in video_thread.h                          */
/**************************************************************************/
void *video_thread_fxn(void *arg)
{
/* Thread parameters and return value */
    video_thread_env *env    = arg;			// see above
    void             *status = VIDEO_THREAD_SUCCESS;	// see above

/* The levels of initialization for initMask */
#define OSDSETUPCOMPLETE	 0x1
#define DISPLAYDEVICEINITIALIZED 0x2
#define CAPTUREDEVICEINITIALIZED 0x4
#define VIDEOENCODERCREATED      0x8
#define VIDEODECODERCREATED      0x10
#define ENCODEDBUFFERALLOCATED   0x20
#define ENGINEOPENED		 0x40
    unsigned int       initMask       = 0x0;

/*  Capture variables */
    Capture_Attrs     cAttrs = Capture_Attrs_OMAP3530_DEFAULT;
    Capture_Handle    hCapture = NULL;
    Buffer_Handle     cBuf;

/*  Display variables */
    Display_Attrs     dAttrs = Display_Attrs_O3530_VID_DEFAULT;
    Display_Handle    hDisplay = NULL;
    Buffer_Handle     dBuf;

/*  Intermediate buffer for encoded video */
    Buffer_Handle      encBuf = NULL;	         // pointer to encoded buffer
    Buffer_Attrs       encBufAttrs = Buffer_Attrs_DEFAULT;
    int                encBufSize = 0;	 // size of encoded buffer

/*  Codec engine variables */
    Engine_Handle	engineHandle = NULL;
    Venc_Handle	        encoderHandle = NULL;	 // handle to video encoder
    Vdec_Handle	        decoderHandle = NULL;	 // handle to video decoder
    VIDENC_Params       eParams = Venc_Params_DEFAULT;
    VIDDEC_Params       dParams = Vdec_Params_DEFAULT;
    VIDENC_DynamicParams eDynParams = Venc_DynamicParams_DEFAULT;
    VIDDEC_DynamicParams dDynParams = Vdec_DynamicParams_DEFAULT;

    Int			ret		= Dmai_EOK;

    BufferGfx_Attrs  gfxAttrs = BufferGfx_Attrs_DEFAULT;
    BufTab_Handle    hBufTabCapture  = NULL, hBufTabDisplay = NULL, hBufTabDecoder = NULL;
    VideoStd_Type    videoStd;
    Int32            bufSize;


    /* Thread Setup Phase -- secure and initialize resources */

    /* Detect which video input is connected on the component input */
    if (Capture_detectVideoStd(NULL, &videoStd, &cAttrs) < 0) {
        printf("Failed to detect input video standard, input connected?\n");
        goto cleanup;
    }

    /* Calculate buffer size needed given a color space */
    bufSize = BufferGfx_calcSize(videoStd, ColorSpace_UYVY);
    bufSize = (bufSize + 4096) & (~0xFFF);
    if (bufSize < 0) {
        printf("Failed to calculate size for video driver buffers\n");
        goto cleanup;
    }

    /* Calculate the dimensions of the video standard */
    if (BufferGfx_calcDimensions(videoStd,
                                 ColorSpace_UYVY, &gfxAttrs.dim) < 0) {
        printf("Failed to calculate dimensions for video driver buffers\n");
        goto cleanup;
    }

    gfxAttrs.colorSpace = ColorSpace_UYVY;

    /* Create a table of buffers to use with the capture driver */
    hBufTabCapture = BufTab_create(NUM_CAPTURE_BUFS, bufSize,
                            BufferGfx_getBufferAttrs(&gfxAttrs));

    if (hBufTabCapture == NULL) {
        printf("Failed to allocate contiguous buffers\n");
        goto cleanup;
    }

    /* Create the capture display driver instance */
    cAttrs.numBufs = NUM_CAPTURE_BUFS;
    hCapture = Capture_create(hBufTabCapture, &cAttrs);

    if( hCapture == NULL) {
	ERR("Failed Capture_create in video_thread_function\n");
	status = VIDEO_THREAD_FAILURE;
	goto cleanup;
    }

    // set output standard to match input
    dAttrs.videoStd = Capture_getVideoStd(hCapture);
    dAttrs.numBufs = NUM_DISPLAY_BUFS;
    dAttrs.rotation = 90;

    /* Create a table of buffers to use with the display driver */
    hBufTabDisplay = BufTab_create(NUM_DISPLAY_BUFS, bufSize,
                            BufferGfx_getBufferAttrs(&gfxAttrs));

    if (hBufTabDisplay == NULL) {
        printf("Failed to allocate contiguous buffers\n");
        goto cleanup;
    }


    hDisplay = Display_create(hBufTabDisplay, &dAttrs);
    if(hDisplay == NULL){
	ERR("Failed to open handle to Display driver in video_thread_fxn\n");
	status = VIDEO_THREAD_FAILURE;
	goto cleanup;
    }



    /* Record that cpature device was opened in initialization bitmask */
    initMask |= CAPTUREDEVICEINITIALIZED;

    /* open the codec engine */
    /* note: codec engine should be opened in each thread that uses it */
    /* open the codec engine */
    /* note: codec engine should be opened in each thread that uses it */
    engineHandle = Engine_open(env->engineName, NULL, NULL);

    if(engineHandle == NULL){
	ERR("engine_setup failed in video_thread_fxn\n");
	status = VIDEO_THREAD_FAILURE;
	goto cleanup;
    }
 
    initMask |= ENGINEOPENED;


    encoderHandle = Venc_create(engineHandle, VIDEO_ENCODER, 
			&eParams, &eDynParams);

    if(encoderHandle == NULL){
	ERR("Failed video_encoder_setup in video_thread_fxn");
	status = VIDEO_THREAD_FAILURE;
	goto cleanup;
    }

    initMask |= VIDEOENCODERCREATED;


    decoderHandle = Vdec_create(engineHandle, VIDEO_DECODER, 
			&dParams, &dDynParams);

    if(decoderHandle == NULL){
	ERR("Failed video_decoder_setup in video_thread_fxn");
	status = VIDEO_THREAD_FAILURE;
	goto cleanup;
    }


    /* Create a table of buffers to use with the video decoder */
    // For codecs that do not use B frames, setting to null is acceptable
    hBufTabDecoder = BufTab_create(NUM_DECODER_BUFS, bufSize,
                            BufferGfx_getBufferAttrs(&gfxAttrs));

    if (hBufTabDecoder == NULL) {
        printf("Failed to allocate contiguous buffers\n");
        goto cleanup;
    }


    Vdec_setBufTab(decoderHandle, hBufTabDecoder);

    initMask |= VIDEODECODERCREATED;


    /* Set buffer size for intermediate buffer (for encoded data)          */
    /* as the size of a full PAL frame                                     */
    encBufSize = 720 * 525 * 2;

    /* Allocate intermediate buffer */
    /* Must use contiguous buffers if passed to DSP! */
    /* (Driver buffers are automatically allocated contiguous */

    encBufAttrs.memParams.align = BUFSIZEALIGN; 
    encBufAttrs.memParams.type = Memory_CONTIGPOOL;

    encBuf = Buffer_create(Dmai_roundUp(encBufSize, BUFSIZEALIGN),
                           &encBufAttrs);


    if (encBuf == NULL) {
        ERR("Failed to allocate video buffer in video_thread_fxn.\n");
	status = VIDEO_THREAD_FAILURE;
	goto cleanup;
    }

    initMask |= ENCODEDBUFFERALLOCATED;

    DBG("Allocated intermediate video buffer of size %d\n", encBufSize);


    /* Thread Execute Phase -- perform I/O and processing */
    DBG("Entering video_thread_fxn processing loop.\n");
    while (!env->quit) {

        Capture_get(hCapture, &cBuf);

	if(Venc_process(encoderHandle, cBuf, encBuf) != Dmai_EOK){
            ERR("encode_video failed in video_thread_fxn\n");
	    status = VIDEO_THREAD_FAILURE;
	    break;
	}

	Display_get(hDisplay, &dBuf);

	ret = Vdec_process(decoderHandle, encBuf, dBuf);

	// Positive return values are success codes, negative are failures
	// Zero is the general success code (EOK)
	if(ret < 0){
		ERR("Vdec_process returned error code: %d\n", ret);
		status = VIDEO_THREAD_FAILURE;
		goto cleanup;
	}

        Capture_put(hCapture, cBuf);

	Display_put(hDisplay, dBuf);

    }

cleanup:
    DBG("Exited video_thread_fxn processing loop\n");
    DBG("\tStarting video thread cleanup\n");
    /* Thread Cleanup Phase -- free resources no longer needed by thread */
    /* Uses the init_bitmask to only free resources that were allocated  */


    /* Close video capture device */
    if (initMask & CAPTUREDEVICEINITIALIZED) {
	Capture_delete(hCapture);
    }

    /* Close video display device */ 
    if (initMask & DISPLAYDEVICEINITIALIZED) {
	Display_delete(hDisplay);
    }

    /* Delete video decoder */
    if (initMask & VIDEODECODERCREATED) {
	Vdec_delete(decoderHandle);
    }

    /* Delete video encoder */
    if (initMask & VIDEOENCODERCREATED) {
	Venc_delete(encoderHandle);
    }

    /* Close the engine */
    if (initMask & ENGINEOPENED){
	Engine_close(engineHandle);
    }

    /* Free intermediate (encoded) buffer */
    if (initMask & ENCODEDBUFFERALLOCATED) {
        DBG("Freed intermediate video buffer at %p\n", encBuf);
	Buffer_delete(encBuf);
    }


    /* Return the status of thread execution */
    DBG("Video thread cleanup complete. Exiting video_thread_fxn\n");
    return (void *)status;
}


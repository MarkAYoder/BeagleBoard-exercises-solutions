{
    "server algorithms": {
        "programName": "app_cfg.xv5T",
        "algs": [
        ],
    },
}

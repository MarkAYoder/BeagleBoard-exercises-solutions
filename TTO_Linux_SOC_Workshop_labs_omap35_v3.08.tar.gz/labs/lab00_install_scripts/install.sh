#! /bin/sh

. ../setpaths.sh
sudo install -d $EXEC_DIR
echo Installing scripts to:  $EXEC_DIR
sudo chmod 777 $EXEC_DIR
sudo install --mode 555 files/*.sh $EXEC_DIR
sudo install --mode 444 files/*.ko $EXEC_DIR


#!/bin/sh
depmod -a

echo Removing in case already loaded: cmemk, dsplink, lpm, sdmak 
modprobe -r cmemk dsplinkk lpm_omap3530 sdmak

echo
echo Inserting 'cmemk' module
##########################################################################
# CMEM Allocation
#    1x5250000            Circular buffer
#    6x829440,1x691200    Video buffers (max D1 PAL)
#    1x345600             Underlying software components (codecs, etc.)
#    1x1                  Dummy buffer used during final flush
#
# v3.04: pools=pools=20x4096,10x131072,12x800000,1x1
##########################################################################
modprobe cmemk allowOverlap=1 phys_start=0x86300000 phys_end=0x87300000 \
        pools=1x5250000,11x829440,1x691200,1x345600,20x4096,1x131072,1x1

echo
echo Inserting 'dsplinkk', 'lpm_omap3530', 'sdmak' modules
# insert DSP/BIOS Link driver
modprobe dsplinkk

# insert Local Power Manager driver
modprobe lpm_omap3530

# insert SDMA driver
modprobe sdmak 

modprobe sdmak

echo
echo


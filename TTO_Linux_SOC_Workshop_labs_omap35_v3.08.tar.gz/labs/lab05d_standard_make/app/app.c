#include <stdio.h>
#include <xdc/runtime/System.h>
#include "app.h"


int main( void )
{
    System_printf( "Hello World (from configuro)\n" );

    printf( "Hello World %d (using stdio)\n", YYYY );

    return 0;
}


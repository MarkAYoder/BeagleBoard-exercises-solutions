/*
 *   main.c
 */

/* Standard Linux headers */
#include <stdio.h>                              //  Always include this header
#include <stdlib.h>                             //  Always include this header
#include <signal.h>                             //  Defines signal-handling functions
#include <unistd.h>                             //  Defines sleep function

/* Codec Engine headers */
#include <xdc/std.h>                            // xdc definitions, must come 1st
#include <ti/sdo/ce/CERuntime.h>                // defines CERuntime_init
#include <ti/sdo/ce/utils/trace/TraceUtil.h>    // CE Tracing utility

/* Application headers */
#include "debug.h"
#include "osd_thread.h"

/* DMAI headers */
#include <ti/sdo/dmai/Dmai.h>

/* The engine to use in this application */
#define ENGINE_NAME     "encodedecode"           // As defined in engine .cfg file

/* Global thread environments */
osd_thread_env osd_env = {0};

/* Store previous signal handler and call it */
void (*pSigPrev)(int sig);

/* Callback called when SIGINT is sent to the process (Ctrl-C) */
void signal_handler(int sig)
{
    DBG( "Ctrl-C pressed, cleaning up and exiting..\n" );

    osd_env.quit = 1;

    if( pSigPrev != NULL )
        (*pSigPrev)( sig );
}


/******************************************************************************
 * main
 ******************************************************************************/
int main(int argc, char *argv[])
{
/* The levels of initialization for initMask */
#define OSDTHREADATTRSCREATED 0x1
#define OSDTHREADCREATED      0x2
    unsigned int    initMask  = 0;
    int             status    = EXIT_SUCCESS;

    void *osdThreadReturn;

    /* Set the signal callback for Ctrl-C */
    pSigPrev = signal( SIGINT, signal_handler );

    /* Always call Dmai_init before using any dmai methods */
    Dmai_init();

    /* Create a thread for osd */
    DBG( "Creating osd thread\n" );
    printf( "\tPress Ctrl-C to exit\n" );

    osdThreadReturn = osd_thread_fxn( (void *) &osd_env );

    initMask |= OSDTHREADCREATED;


//cleanup:
    /* Nothing to cleanup in main(), yet. */

    exit( status );
}


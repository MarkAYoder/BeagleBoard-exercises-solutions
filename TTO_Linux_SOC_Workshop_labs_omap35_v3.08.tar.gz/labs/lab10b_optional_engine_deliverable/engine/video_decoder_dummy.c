/* 
 * audio_decoder.c
 */

/* Standard Linux headers */
#include <stdio.h>            // always include stdio.h
#include <stdlib.h>           // always include stdlib.h
#include <string.h>	      // memset, memcpy, strcmp, strcpy

/* Codec Engine headers */
#include <xdc/std.h>			// xdc base definitions. Must come 1st
#include <ti/sdo/ce/Engine.h>		// Engine_open, Engine_Handle, etc
#include <ti/sdo/ce/video/viddec.h>	// AUDDEC_create, AUDDEC_Handle, etc


/******************************************************************************
 * __video_decoder_dummy
 ******************************************************************************/
/* This dummy function simply exercises all four audio decoder functions to   */
/*    ensure they are added into the engine .o file. This function should     */
/*    never be called by the application                                      */
/*                                                                            */
/******************************************************************************/
void __video_decoder_dummy(void)
{
    VIDDEC_Handle           decoderHandle;	
    Engine_Handle	    engineHandle = NULL;
    VIDDEC_InArgs           inArgs;	
    VIDDEC_OutArgs          outArgs;
    XDM_BufDesc             inBufDesc;
    XDM_BufDesc             outBufDesc;	
    VIDDEC_Status status;
    VIDDEC_DynamicParams dynParams;


    decoderHandle = VIDDEC_create(engineHandle, "invalid", NULL);
    VIDDEC_process(decoderHandle, &inBufDesc, &outBufDesc, &inArgs, &outArgs);
    VIDDEC_control(decoderHandle, XDM_GETSTATUS, &dynParams, &status);
    VIDDEC_delete(decoderHandle);

}

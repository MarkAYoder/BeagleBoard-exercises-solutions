/* 
 * audio_decoder.c
 */

/* Standard Linux headers */
#include <stdio.h>            // always include stdio.h
#include <stdlib.h>           // always include stdlib.h
#include <string.h>	      // memset, memcpy, strcmp, strcpy

/* Codec Engine headers */
#include <xdc/std.h>			// xdc base definitions. Must come 1st
#include <ti/sdo/ce/Engine.h>		// Engine_open, Engine_Handle, etc
#include <ti/sdo/ce/video/videnc.h>	// AUDDEC_create, AUDDEC_Handle, etc


/******************************************************************************
 * __video_encoder_dummy
 ******************************************************************************/
/* This dummy function simply exercises all four audio decoder functions to   */
/*    ensure they are added into the engine .o file. This function should     */
/*    never be called by the application                                      */
/*                                                                            */
/******************************************************************************/
void __video_encoder_dummy(void)
{
    VIDENC_Handle           encoderHandle;	
    Engine_Handle	    engineHandle = NULL;
    VIDENC_InArgs           inArgs;	
    VIDENC_OutArgs          outArgs;
    XDM_BufDesc             inBufDesc;
    XDM_BufDesc             outBufDesc;	
    VIDENC_Status status;
    VIDENC_DynamicParams dynParams;


    encoderHandle = VIDENC_create(engineHandle, "invalid", NULL);
    VIDENC_process(encoderHandle, &inBufDesc, &outBufDesc, &inArgs, &outArgs);
    VIDENC_control(encoderHandle, XDM_GETSTATUS, &dynParams, &status);
    VIDENC_delete(encoderHandle);

}

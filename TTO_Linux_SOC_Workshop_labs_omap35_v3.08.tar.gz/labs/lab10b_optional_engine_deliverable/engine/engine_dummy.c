/* 
 * audio_decoder.c
 */

/* Standard Linux headers */
#include <stdio.h>            // always include stdio.h
#include <stdlib.h>           // always include stdlib.h

/* Codec Engine headers */
#include <xdc/std.h>			// xdc base definitions. Must come 1st
#include <ti/sdo/ce/CERuntime.h>	// defines CERuntime_init
#include <ti/sdo/ce/Engine.h>		// Engine_open, Engine_Handle, etc


/******************************************************************************
 * __engine_dummy
 ******************************************************************************/
/* This dummy function simply exercises all engine functions to   */
/*    ensure they are added into the engine .o file. This function should     */
/*    never be called by the application                                      */
/*                                                                            */
/******************************************************************************/
void __engine_dummy(void)
{
    Engine_Handle	    engineHandle = NULL;

    CERuntime_init();
    engineHandle = Engine_open("dummyname", NULL, NULL);
    Engine_close(engineHandle);

}

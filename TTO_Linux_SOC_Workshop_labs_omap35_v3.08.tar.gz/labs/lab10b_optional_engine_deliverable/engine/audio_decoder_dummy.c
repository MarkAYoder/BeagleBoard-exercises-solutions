/* 
 * audio_decoder.c
 */

/* Standard Linux headers */
#include <stdio.h>            // always include stdio.h
#include <stdlib.h>           // always include stdlib.h

/* Codec Engine headers */
#include <xdc/std.h>			// xdc base definitions. Must come 1st
#include <ti/sdo/ce/Engine.h>		// Engine_open, Engine_Handle, etc
#include <ti/sdo/ce/audio/auddec.h>	// AUDDEC_create, AUDDEC_Handle, etc


/******************************************************************************
 * __audio_decoder_dummy
 ******************************************************************************/
/* This dummy function simply exercises all four audio decoder functions to   */
/*    ensure they are added into the engine .o file. This function should     */
/*    never be called by the application                                      */
/*                                                                            */
/******************************************************************************/
void __audio_decoder_dummy(void)
{
    AUDDEC_Handle           decoderHandle;	// Speech Decoder Handle
    Engine_Handle	    engineHandle = NULL;
    AUDDEC_InArgs           inArgs;	// input args for AUDDEC_process
    AUDDEC_OutArgs          outArgs;	// output (return) from AUDDEC_process
    XDM_BufDesc             inBufDesc;  // buffer descriptor for input buffer
    XDM_BufDesc             outBufDesc;	// buffer descriptor for output buffer
    AUDDEC_Status status;
    AUDDEC_DynamicParams dynParams;


    decoderHandle = AUDDEC_create(engineHandle, "invalid", NULL);
    AUDDEC_process(decoderHandle, &inBufDesc, &outBufDesc, &inArgs, &outArgs);
    AUDDEC_control(decoderHandle, XDM_GETSTATUS, &dynParams, &status);
    AUDDEC_delete(decoderHandle);

}

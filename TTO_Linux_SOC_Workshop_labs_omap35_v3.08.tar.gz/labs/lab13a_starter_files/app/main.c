//============================================================================
//
//    FILE NAME : main.c
//
//    ALGORITHM : MIXER
//
//    VENDOR    : TTO
//
//    TARGET DSP: C64x+
//
//    PURPOSE   : This file contains code to test the MIXER algorithm.
//
//    Algorithm Wizard Version 1.00.00 Auto-Generated Component
//
//    Creation Date: Wed - 18 August 2010
//    Creation Time: 12:51 AM
//
//============================================================================

#include <xdc/std.h>
// which includes: stdarg.h, stddef.h

#include <ti/sdo/ce/CERuntime.h>
#include <ti/sdo/ce/osal/Memory.h>                    // Contiguous memory alloc functions

#include <ti/sdo/ce/universal/universal.h>
// which includes: iuniversal.h, xdm.h, ialg.h, xdas.h, Engine.h, visa.h, skel.h

#include <stdint.h> // used for definitions like uint32_t, ...
#include <string.h> // used for memset/memcpy commands

// Note1: Make sure you have added this algorithms repository as a -i compiler option;
//        that is, make sure the path that contains the folder "tto" is provided as
//        a -i include path. The compiler will concatenate the -i path, along with the
//        specified in the <> to find the actual header file.
// Note2: The 'mixer_tto.h' header also includes: imyalg.h

#include <tto/codecs/mixer/mixer_tto.h>

//============================================================================
//
//    Prototypes
//
//============================================================================
int main ( void );
void setup_IMIXER_buffers ( void );
void error_check ( Uint32 event, XDAS_Int32 val );

//============================================================================
//
//    Global/Static Variables 
//
//    Note: We chose to make most of the variables and arrays 'static local'
//          to make debugging easier for our simple codec engine test example.
//          By declaring them this way, they remain in scope during the entire
//          program.
//
//============================================================================
#define PROGRAM_NAME        "universal_test"
#define ENGINE_NAME         "myEngine"
#define ALGO_NAME           "mixer"

static String               sProgName   = PROGRAM_NAME;
static String               sEngineName = ENGINE_NAME;
static String               sAlgoName   = ALGO_NAME;

static Engine_Handle        hEngine     = NULL;
static UNIVERSAL_Handle     hUniversal  = NULL;

static IMIXER_Params        myParams;

#define IN_BUFFER_SIZE      20
#define OUT_BUFFER_SIZE     20
#define INOUT_BUFFER_SIZE   16
#define STATUS_BUFFER_SIZE  16

static XDAS_Int8            *in0;              //[IN_BUFFER_SIZE];
static XDAS_Int8            *in1;              //[IN_BUFFER_SIZE];
static XDAS_Int8            *out0;             //[OUT_BUFFER_SIZE];
static XDAS_Int8            *status0;          //[STATUS_BUFFER_SIZE];

static XDM1_BufDesc         myInBufs;
static XDM1_BufDesc         myOutBufs;
static XDM1_BufDesc         myInOutBufs;
static IMIXER_InArgs        myInArgs;
static IMIXER_OutArgs       myOutArgs;
static IMIXER_DynamicParams myDynParams;
static IMIXER_Status        myStatus;

#define RETURN_ERROR 0
#define RETURN_SUCCESS 1

static unsigned int         funcReturn  = RETURN_SUCCESS;

static XDAS_Int32           rStatus     = 0;

typedef enum TEST_ERROR_CHECK {                 // Used to indicate which CE function was just
  TEST_ENGINE_OPEN  = 0,                        //   executed. To improve readability of the CE
  TEST_ALGO_CREATE  = 1,                        //   code in the main routine, the error/test
  TEST_ALGO_PROCESS = 2,                        //   code was placed into its own function.
  TEST_ALGO_CONTROL = 3,
  TEST_ALGO_DELETE  = 4
} TEST_ERROR_CHECK;

// ===========================================================================
// MIXER_ Function Macros
//
// The following three macros make it easier to call the algorithm's create, process,
// and control methods.  They provide recasting of the functions and arguments from
// the MIXER algorithm, to the UNIVERSAL API.  This is needed since the Codec Engine
// framework implements the common API, which provides portability and ease-of-use.
//
#define MIXER_create( hEngine, sAlgoName, Params ) UNIVERSAL_create( hEngine, sAlgoName, ( IUNIVERSAL_Params * )&Params )
#define MIXER_process( hUniversal, InBufs, OutBufs, InOutBufs, InArgs, OutArgs ) UNIVERSAL_process( hUniversal, &InBufs, &OutBufs, &InOutBufs, ( IUNIVERSAL_InArgs * )&InArgs, ( IUNIVERSAL_OutArgs * )&OutArgs )
#define MIXER_control( hEngine, eCmdId, DynParams, Status ) UNIVERSAL_control( hEngine, eCmdId, ( UNIVERSAL_DynamicParams * )&DynParams, ( UNIVERSAL_Status * )&Status )


//============================================================================
//
//    Functions
//
//============================================================================

int main( void )
{

//  ====  Open the Codec Engine ==============================================

    CERuntime_init();

    hEngine = Engine_open( sEngineName, NULL, NULL );
    error_check( TEST_ENGINE_OPEN,( XDAS_Int32 ) hEngine );


//  ====  Create an Algo Instance ============================================

    // Initialize the params used for the create call
	
    myParams.base.size = sizeof( IMIXER_Params );

    //The MIXER_create() function creates an instance of our algorithm; you
    // can call the generic UNIVERSAL_create() function, but you would need to 
    // correctly cast the parameters. The iMIXER.h file defines macros which 
    // simplify the _create, _process, and _control function calls.
	
    hUniversal = MIXER_create( hEngine, sAlgoName, myParams );

    error_check( TEST_ALGO_CREATE, ( XDAS_Int32 ) hUniversal );


//  ====  Run the Algorithm ==================================================

    setup_IMIXER_buffers();

    // Default values were applied; please change if you want to select other values.

    myInArgs.base.size = sizeof( IMIXER_InArgs );
    myInArgs.gain0     = 0x3fff;
    myInArgs.gain1     = 0x3fff;

    //IMIXER_OutArgs was not extended, so no additional values must be set in myOutArgs.

    myOutArgs.base.size = sizeof( IMIXER_OutArgs );

    rStatus = MIXER_process( hUniversal, myInBufs, myOutBufs, myInOutBufs, myInArgs, myOutArgs );

    error_check( TEST_ALGO_PROCESS, rStatus );


//  ====  Call Algo control function =========================================

    //IMIXER_DynamicParams was not extended, so no additional values must be set in myDynParams.
	
    myDynParams.base.size = sizeof( IMIXER_DynamicParams );
    myStatus.base.size    = sizeof( IMIXER_Status );

    rStatus = MIXER_control( hUniversal, XDM_GETVERSION, myDynParams, myStatus );

    if ( !rStatus )
    {
        printf( "Program '%s': Algo '%s' control call succeded\n",sProgName, sAlgoName );

        printf( "\tAlg version:  %s\n", ( rStatus == UNIVERSAL_EOK ?
              ( ( char * )myStatus.base.data.descs[0].buf ) : "[unknown]" ) );
    }
    else
    {
        fprintf( stderr, "Program '%s': ERROR: Algo '%s' control call failed; rStatus=0x%x\n", sProgName, sAlgoName, ( unsigned int ) rStatus );
    }


//  ====  Delete the Algo Instance ===========================================

    UNIVERSAL_delete( hUniversal );


//  ====  Close the Codec Engine =============================================

    Engine_close ( hEngine );


//  ====  Return from Main Function ==========================================

#ifdef _DEBUG_
    printf( "Program '%s': Function main() now exiting.\n", sProgName );
#endif

    //while( 1 );

    return( funcReturn );

}

// ============================================================================
// Error checking and reporting routine
// ============================================================================
void error_check( Uint32 event, XDAS_Int32 rVal )
{
    switch( event )
	{
        case ( TEST_ENGINE_OPEN ) : 
            if ( rVal == 0 )  //hEngine
            {
                funcReturn = RETURN_ERROR;
                fprintf( stderr, "Program '%s': ERROR: Can't open engine '%s'\n", sProgName, sEngineName );
            }
#ifdef _DEBUG_
            else
            {
                printf( "Program '%s': Engine '%s' opened with handle = 0x%x\n", sProgName, sEngineName, ( unsigned int ) hEngine );
            }
#endif
            break;

        case ( TEST_ALGO_CREATE ) : 
            if ( rVal == 0 ) 
			{
                funcReturn = RETURN_ERROR;
                fprintf( stderr, "Program '%s': ERROR: Can't open algorithm '%s'\n", sProgName, sAlgoName );
            }
#ifdef _DEBUG_
            else
            {
                printf( "Program '%s': Algo '%s' opened with handle = 0x%x\n", sProgName, sAlgoName, ( unsigned int ) hUniversal );
            }
#endif
            break;

        case ( TEST_ALGO_PROCESS ) : 
            if ( rVal != UNIVERSAL_EOK )   //rStatus
			{
                fprintf( stderr, "Program '%s': ERROR: While processing algorithm %s: status = %d\n", sProgName, sAlgoName, ( unsigned int ) rStatus );

                printf( "MYALG process function failed with status = 0x%x, "
                        "extendedError = 0x%x\n", ( unsigned int ) rStatus, ( unsigned int ) myOutArgs.base.extendedError );
            }
#ifdef _DEBUG_
            else
            {
                printf( "Program '%s': Algo '%s' process call completed successfull.\n", sProgName, sAlgoName );
            }
#endif
            break;
    }
}
// ============================================================================
// Buffer setup
// ============================================================================

void setup_IMIXER_buffers( void )
{

    //  ====  ALLOCATE BUFFERS  ===============================================
	//  
	//  - Buffers are allocated with the Codec Engine's contigAlloc function 
	//  - On ARM, this fxn alloc's memory from the CMEM driver, which is req'd
	//    when passing data to the DSP. A contiguous allocation is made when
	//    run on the DSP, but this maps to a simple MEM allocation.
	//  - This prevents a failure on architectures like OMAP3530 which provide
	//    an MMU in the DSP's memory path.

    in0     = Memory_contigAlloc( IN_BUFFER_SIZE, 8 );
    in1     = Memory_contigAlloc( IN_BUFFER_SIZE, 8 );
    out0    = Memory_contigAlloc( OUT_BUFFER_SIZE, 8 );
    status0 = Memory_contigAlloc( STATUS_BUFFER_SIZE, 8 );


    //  ====  INITIALIZE BUFFERS  =============================================
	//  
	//  - We chose to use a simple data set for testing our algorithm.
	//  - In "real" life you would want to enhance this test program with test
	//    data that validates your algorithm. 

    memset( in0,    0xA, IN_BUFFER_SIZE  );
    memset( in1,    0xB, IN_BUFFER_SIZE  );
    memset( out0,   0x0, OUT_BUFFER_SIZE );

    //  === Setup buffer descriptors for calls used in the MIXER_process()
    //      and MIXER_control() functions

    myInBufs.numBufs            = 2;
    myInBufs.descs[0].bufSize   = IN_BUFFER_SIZE;
    myInBufs.descs[0].buf       = ( XDAS_Int8 * ) in0;
    myInBufs.descs[1].bufSize   = IN_BUFFER_SIZE;
    myInBufs.descs[1].buf       = ( XDAS_Int8 * ) in1;

    myOutBufs.numBufs           = 1;
    myOutBufs.descs[0].bufSize  = OUT_BUFFER_SIZE;
    myOutBufs.descs[0].buf      = ( XDAS_Int8 * ) out0;

    myInOutBufs.numBufs         = 0;

    myStatus.base.data.numBufs          = 1;
    myStatus.base.data.descs[0].bufSize = STATUS_BUFFER_SIZE;
    myStatus.base.data.descs[0].buf     = ( XDAS_Int8 * ) status0;


}


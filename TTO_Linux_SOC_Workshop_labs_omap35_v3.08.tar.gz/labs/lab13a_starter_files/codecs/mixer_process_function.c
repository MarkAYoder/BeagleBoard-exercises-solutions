/*
 *  ======== MIXER_TTO_process ========
 */
/* ARGSUSED - this line tells the TI compiler not to warn about unused args. */
XDAS_Int32 MIXER_TTO_process(IUNIVERSAL_Handle h,
        XDM1_BufDesc *inBufs, XDM1_BufDesc *outBufs, XDM1_BufDesc *inOutBufs,
        IUNIVERSAL_InArgs *universalInArgs,
        IUNIVERSAL_OutArgs *universalOutArgs)
{
    XDAS_Int32 numInBytes, i;
    XDAS_Int16 *pIn0, *pIn1, *pOut, gain0, gain1;

    /* Local casted variables to ease operating on our extended fields */
    IMIXER_InArgs *inArgs = (IMIXER_InArgs *)universalInArgs;
    IMIXER_OutArgs *outArgs = (IMIXER_OutArgs *)universalOutArgs;

    /*
     * Note that the rest of this function will be algorithm-specific.  In
     * the initial generated implementation, this process() function simply
     * copies the first inBuf to the first outBuf.  But you should modify
     * this to suit your algorithm's needs.
     */

    /*
     * Validate arguments.  You should add your own algorithm-specific
     * parameter validation and potentially algorithm-specific return values.
     */
    if ((inArgs->base.size != sizeof(*inArgs)) ||
            (outArgs->base.size != sizeof(*outArgs))) {
        outArgs->base.extendedError = XDM_UNSUPPORTEDPARAM;

        return (IUNIVERSAL_EUNSUPPORTED);
    }

    /* validate that there's 2 inBufs and 1 outBuf */
    if ((inBufs->numBufs != 2) || (outBufs->numBufs != 1)) {
        outArgs->base.extendedError = XDM_UNSUPPORTEDPARAM;

        return (IUNIVERSAL_EFAIL);
    }

    /* validate that buffer sizes are the same */
    if (inBufs->descs[0].bufSize != inBufs->descs[1].bufSize)
    	return IUNIVERSAL_EFAIL;
    if (inBufs->descs[0].bufSize != outBufs->descs[0].bufSize)
    	return IUNIVERSAL_EFAIL;

    // DO IT!
    pIn0 = (XDAS_Int16*)inBufs->descs[0].buf;
    pIn1 = (XDAS_Int16*)inBufs->descs[1].buf;
    pOut = (XDAS_Int16*)outBufs->descs[0].buf;
    gain0 = inArgs->gain0;
    gain1 = inArgs->gain1;
    numInBytes = inBufs->descs[0].bufSize;

    for(i=0; i<numInBytes/2; i++)
    {
    	pOut[i] = (pIn0[i]*(XDAS_Int32)gain0 + pIn1[i]*(XDAS_Int32)gain1) >> 15;
    }

    /* report how we accessed the input buffers */
    inBufs->descs[0].accessMask = 0;
    XDM_SETACCESSMODE_READ(inBufs->descs[0].accessMask);
    inBufs->descs[1].accessMask = 0;
    XDM_SETACCESSMODE_READ(inBufs->descs[1].accessMask);

    /* report how we accessed the output buffer */
    outBufs->descs[0].accessMask = 0;
    XDM_SETACCESSMODE_WRITE(outBufs->descs[0].accessMask);

    /*
     * Fill out the rest of the outArgs struct, including any extended
     * outArgs your algorithm has defined.
     */
    outArgs->base.extendedError = 0;

    return (IUNIVERSAL_EOK);
}

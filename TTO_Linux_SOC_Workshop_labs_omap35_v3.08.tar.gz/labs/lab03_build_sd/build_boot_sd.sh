#!/bin/bash

# Color variables
red='\e[0;31m'
RED='\e[1;31m'
yellow='\e[0;33m'
blue='\e[0;34m'
BLUE='\e[1;34m'
cyan='\e[0;36m'
CYAN='\e[1;36m'
NC='\e[0m' # No Color

# Variable specifying location of the sd card image files
. ../setpaths.sh
IMAGE_DIR=$PWD
echo  
echo ............ IMAGE_DIR = ${IMAGE_DIR}
#PSP=${PSP_DIR}
echo ............ PSP_DIR = $PSP_DIR
echo 


# Check to see if command line argument was provided
if [ -z "$SCSI_DEV" ]; then 
	export SCSI_DEV=/dev/sdb
fi

sudo sg_map -i
echo -e "${cyan}IMPORTANT: please verify that USB mmc/sd card reader is mapped to $SCSI_DEV"
echo            if not you could permanently damage a memory device on your
echo            computer!
echo To run script with a different device node, either modify this script or
echo -e "           run as: ${NC}"
echo \# SCSI_DEV=/dev/sdX ./build_sd.sh
echo -e " \n"
echo -e "${cyan}Continue? \( press y to continue, anything else to quit \) : ${NC}"
read INVAR
if [ "$INVAR" != "y" ]; then
	exit
fi
echo
echo -e "${cyan}Utility will format sd or mmc card with 1 GB size "
echo SD or mmc cards that are larger in size are allowed but will effectively
echo \t become 1 GB in size
echo -e "sd or mmc cards that are smaller than 1 GB in size are *not* allowed ${NC}"
sudo umount ${SCSI_DEV}
sudo umount ${SCSI_DEV}1
sudo umount ${SCSI_DEV}2
echo
echo -e "\n\n${cyan}*****  Creating partition 1 . ${NC}\n"
sudo sfdisk -D -H255 -S63 -C120 $SCSI_DEV < ${IMAGE_DIR}/sfdisk_p1.input
echo
echo -e "\n${cyan}*****  Creating partition 2 .. ${NC}\n"
sudo sfdisk -N2 -H255 -S63 -C120 $SCSI_DEV < ${IMAGE_DIR}/sfdisk_p2.input
echo
echo -e "\n${cyan}*****  Formatting partition 1 ... ${NC}\n"
sudo mkfs.vfat -F 32 ${SCSI_DEV}1

echo -e "\n${cyan}*****  Formatting partition 2 .... ${NC}\n"
sudo mkfs.ext3 ${SCSI_DEV}2

echo -e "\n${cyan}***** Mounting new partitions as /mnt/disk and /mnt/disk-1 ${NC}\n"
sudo mkdir -p /mnt/disk
sudo mkdir -p /mnt/disk-1
sudo mount ${SCSI_DEV}1 /mnt/disk
sudo mount ${SCSI_DEV}2 /mnt/disk-1

echo -e "\n${cyan}*****  Copying MLO (i.e. x-loader) to partition 1 ${NC}\n"
sudo cp ${PSP_DIR}/xloader/x-load.bin.ift /mnt/disk/MLO

echo -e "\n${cyan}*****  Copying u-boot to partition 1 ${NC}\n"
sudo cp ${PSP_DIR}/uboot/u-boot.bin /mnt/disk/u-boot.bin

echo -e "\n${cyan}*****  Copying uImage to partition 1 ${NC}\n"
sudo cp ${PSP_DIR}/linux_kernel/uImage /mnt/disk/uImage

#echo -e "\n${cyan}*****  Untaring root filesystem to partition 2 ... ${red}This could take >10 minutes ${NC}\n"
#sudo cp ${PSP_DIR}/linux_filesys /mnt/disk-1

echo -e "\n${cyan}*****  Now unmounting 'disk' and 'disk-1'${NC}\n"
sudo umount /mnt/disk
sudo umount /mnt/disk-1
sudo rmdir /mnt/disk
sudo rmdir /mnt/disk-1

echo -e "\n${cyan}*****  Build_sh script has completed ***** ${NC}\n"
echo


#! /bin/sh

###############################################################################
#                                                                             #
#   Absolute Paths must be set for each system, otherwise the build will not  #
#     be able to find the correct libraries and packages                      #
#                                                                             #
###############################################################################

######## Uncomment the following line for verbose XDC builds##########
#export XDCOPTIONS="-v"

############# Paths for TI Tools and Libraries ################################

# User's home location:  (i.e. /home/user)
export HOME="/home/user"

# The installation directory of the DVEVM software
export DVEVM_INSTALL_DIR="$HOME/ti-dvsdk_omap3530-evm_4_00_00_17"

# Installation directory of the software development kit (may be same as above)
export SDK_INSTALL_DIR="$DVEVM_INSTALL_DIR"

### TI libraries and framework locations ###

# Where the BIOS tools are installed
export BIOS_INSTALL_DIR="$SDK_INSTALL_DIR/dspbios_5_41_03_17"

# Where the Bios Utilities are installed
export BIOSUTILS_INSTALL_DIR="$SDK_INSTALL_DIR/biosutils_1_02_02"

# Where the Codec Engine package is installed.
export CE_INSTALL_DIR="$DVEVM_INSTALL_DIR/codec-engine_2_25_05_16"

# Where the CMEM (contiguous memory allocator) package is installed.
export CMEM_INSTALL_DIR="$DVEVM_INSTALL_DIR/linuxutils_2_25_04_10"

# Where the DSP Link package is installed.
export DSPLINK_INSTALL_DIR="$DVEVM_INSTALL_DIR/dsplink_linux_1_65_00_01"

# Where the framework components are installed
export FC_INSTALL_DIR="$SDK_INSTALL_DIR/framework-components_2_25_02_06"

# Where the XDAIS package is installed.
export XDAIS_INSTALL_DIR="$DVEVM_INSTALL_DIR/xdais_6_25_02_11"

# Where the RTSC tools package is installed.
export XDC_INSTALL_DIR="$DVEVM_INSTALL_DIR/xdctools_3_16_03_36"

# Where the dmai library is installed
export DMAI_INSTALL_DIR="$SDK_INSTALL_DIR/dmai_2_05_00_18"

# Path to Linux Library headers (i.e. alsa.h)
export LLIB_INSTALL_DIR="$SDK_INSTALL_DIR/linux-devkit/arm-none-linux-gnueabi/usr"
export LINUXLIBS_INSTALL_DIR="$SDK_INSTALL_DIR/linux-devkit/arm-none-linux-gnueabi/usr"

# Where local power manager is installed
export LPM_INSTALL_DIR="$SDK_INSTALL_DIR/local-power-manager_1_24_02_09"

# Where c6accel package is installed
export C6ACCEL_INSTALL_DIR="$SDK_INSTALL_DIR/c6accel_1_00_00_04"

### TI DSP Compiler ###

# Where the C6000 code generation tools are installed
export C6000_CG="/home/user/cgt6x_6_1_14"
CODEGEN_INSTALL_DIR="$C6000_CG"



###### Paths for x86 Linux (i.e. Ubuntu) #####################################

# Where the Linux x86 tools are installed
export LINUX86_DIR="/usr"

# Path to the Linux x86 gcc tool
export LINUX86_GCC="$LINUX86_DIR/bin/gcc"


####### Paths for Cortex-A8 (Code Sourcery toolchain)

export CS_INSTALL_PATH="$HOME/CodeSourcery/Sourcery_G++_Lite"
export CS_GCC="$CS_INSTALL_PATH/bin/arm-none-linux-gnueabi-gcc"

export CSTOOL_DIR="$HOME/CodeSourcery/Sourcery_G++_Lite"
export CSTOOL_PREFIX=$CSTOOL_DIR"/bin/arm-none-linux-gnueabi-"

# Where linux source (i.e. sdk) is installed
export LINUX_KERNEL_DIR="$SDK_INSTALL_DIR/psp/linux-kernel-source"
export PSP_DIR="$HOME/psp_rebuild_omap3"

###### Paths for Target's Filesystem #############################################
# Where the target board's filesystem is located. This is linked from the
# PSP directory in our first lab using something like:  
#      ln -s /home/user/psp_rebuild_omap3 /home/user/targetfs
TARGET_FS_DIR="$HOME/targetfs"

# Where to copy the resulting executables and data to (when executing 'make
# install') in a proper file structure. This EXEC_DIR should either be visible
# from the target, or you will have to copy this (whole) directory onto the
# target filesystem.
export EXEC_DIR="$TARGET_FS_DIR/opt/workshop"

export PATH="$XDC_INSTALL_DIR:$PATH"


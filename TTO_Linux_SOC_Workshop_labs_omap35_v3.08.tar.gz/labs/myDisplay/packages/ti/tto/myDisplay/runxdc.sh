#! /bin/sh 
#  use: /bin/sh -vx  for debugging

#  import install paths
#  putting the first period before the shell invokation keeps the changes
#      to environment variables set here. Otherwise, changes to environment
#      are only within the context of the executed script
. ../../../../../setpaths.sh

#  Define search paths for included packages
export XDCPATH="$CE_INSTALL_DIR/packages;$XDAIS_INSTALL_DIR/packages;$DSPLINK_INSTALL_DIR/packages;$CMEM_INSTALL_DIR/packages;$FC_INSTALL_DIR/packages;$XDC_INSTALL_DIR/packages;$BIOS_INSTALL_DIR/packages;$DMAI_INSTALL_DIR/packages;$LINUX_KERNEL_DIR/include;$LINUX_KERNEL_DIR/arch/arm/include"

#  Define options for execution
export XDCBUILDCFG=$(pwd)"/../../../../../config.bld"

#  Execute xdc command
xdc $@

/* Standard Linux headers */
#include <stdio.h>		// always include stdio.h
#include <stdlib.h>		// always include stdlib.h
#include <string.h>             // defines memset and memcpy methods



/* dmai headers */
#include <ti/sdo/dmai/Dmai.h>
#include <ti/sdo/dmai/Display.h>
#include <ti/sdo/dmai/BufTab.h>
#include <ti/sdo/dmai/Buffer.h>
#include <ti/sdo/dmai/BufferGfx.h>

#include <ti/sdo/dmai/Cpu.h>
#include <ti/sdo/dmai/ColorSpace.h>


#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <linux/fb.h>

//#include <linux/omapfb.h>

#include "priv/_VideoBuf.h"
#include "priv/_Display.h"

typedef enum {
    myVideoStd_AUTO = 0,      /**< Automatically select standard (if supported) */
    myVideoStd_CIF,           /**< CIF @ 30 frames per second */
    myVideoStd_SIF_NTSC,      /**< SIF @ 30 frames per second */
    myVideoStd_SIF_PAL,       /**< SIF @ 25 frames per second */
    myVideoStd_VGA,           /**< VGA (640x480) @ 60 frames per second */
    myVideoStd_D1_NTSC,       /**< D1 NTSC @ 30 frames per second */
    myVideoStd_D1_PAL,        /**< D1 PAL @ 25 frames per second */
    myVideoStd_480P,          /**< D1 Progressive NTSC @ 60 frames per second */
    myVideoStd_576P,          /**< D1 Progressive PAL @ 50 frames per second */
    myVideoStd_720P_60,       /**< 720P @ 60 frames per second */
    myVideoStd_720P_50,       /**< 720P @ 50 frames per second */
    myVideoStd_1080I_30,      /**< 1080I @ 30 frames per second */
    myVideoStd_1080I_25,      /**< 1080I @ 25 frames per second */
    myVideoStd_1080P_30,      /**< 1080P @ 30 frames per second */
    myVideoStd_1080P_25,      /**< 1080P @ 25 frames per second */
    myVideoStd_1080P_24,      /**< 1080P @ 24 frames per second */
// Add support for AM3517 evm 
    myVideoStd_480_272,
    myVideoStd_COUNT
} myVideoStd_Type;


typedef enum {
    myColorSpace_NOTSET = -1,
    myColorSpace_YUV420PSEMI = 0,
    myColorSpace_YUV422PSEMI,
    myColorSpace_UYVY,
    myColorSpace_RGB888,
    myColorSpace_RGB565,
    myColorSpace_2BIT,
    myColorSpace_YUV420P,
    myColorSpace_YUV422P,
    myColorSpace_YUV444P,
    myColorSpace_GRAY,
//  Extend the color space structure with the ARGB color space
    myColorSpace_ARGB,
    myColorSpace_COUNT
} myColorSpace_Type;


typedef struct myDisplay_Attrs {
    Int                 numBufs;
    Display_Std         displayStd;
    myVideoStd_Type       videoStd;
    Display_Output      videoOutput;  
    Char               *displayDevice;
    Int                 rotation;
    myColorSpace_Type     colorSpace;
    Int                 streamonDisable;
} myDisplay_Attrs;


extern const myDisplay_Attrs myDisplay_Attrs_O3530_OSD_DEFAULT;


Int mySetDisplayBuffer(Display_Handle hDisplay, Int displayIdx);
Display_Handle myDisplay_fbdev_create(BufTab_Handle hBufTab, myDisplay_Attrs *attrs);
Int myDisplay_fbdev_get(Display_Handle hDisplay, Buffer_Handle *hBufPtr);
Int myDisplay_fbdev_put(Display_Handle hDisplay, Buffer_Handle hBuf);



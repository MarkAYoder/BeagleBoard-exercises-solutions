/*
 * myDisplay.c
 *
 * Extends the functionality of the standard DMAI OSD layer
 *
 */

/* Standard Linux headers */
#include <stdio.h>		// always include stdio.h
#include <stdlib.h>		// always include stdlib.h
#include <string.h>             // defines memset and memcpy methods


/* dmai headers */
#include <ti/sdo/dmai/Dmai.h>
#include "myDisplay.h"
#include <ti/sdo/dmai/BufTab.h>
#include <ti/sdo/dmai/Buffer.h>
#include <ti/sdo/dmai/BufferGfx.h>

#include <ti/sdo/dmai/Cpu.h>
#include <ti/sdo/dmai/ColorSpace.h>


#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <linux/fb.h>

#include <linux/omapfb.h>

#include "priv/_VideoBuf.h"
#include "priv/_Display.h"

const myDisplay_Attrs myDisplay_Attrs_O3530_OSD_DEFAULT = {
    1,
    Display_Std_FBDEV,
    myVideoStd_VGA,
    Display_Output_LCD,
    "/dev/fb0",
    0,
    myColorSpace_RGB565,
    0
};



/******************************************************************************
 * setDisplayBuffer
 ******************************************************************************/
Int mySetDisplayBuffer(Display_Handle hDisplay, Int displayIdx)
{
    struct fb_var_screeninfo varInfo;

    if (ioctl(hDisplay->fd, FBIOGET_VSCREENINFO, &varInfo) == -1) {
        printf("Failed FBIOGET_VSCREENINFO (%s)\n", strerror(errno));
        return Dmai_EFAIL;
    }

    varInfo.yoffset = varInfo.yres * displayIdx;

    if (varInfo.rotate == 1 || varInfo.rotate == 3){
	varInfo.yoffset = varInfo.xres * displayIdx;
    }

    if (ioctl(hDisplay->fd, FBIOPAN_DISPLAY, &varInfo) == -1) {
        printf("Failed FBIOPAN_DISPLAY (%s)\n", strerror(errno));
        return Dmai_EFAIL;
    }

    if (ioctl(hDisplay->fd, OMAPFB_WAITFORVSYNC, &varInfo) == -1) {
        printf("Failed OMAPFB_WAITFORVSYNC (%s)\n", strerror(errno));
        return Dmai_EFAIL;
    }

    return Dmai_EOK;
}

/******************************************************************************
 * cleanup
 ******************************************************************************/
static Int cleanup(Display_Handle hDisplay)
{
    Int                      ret     = Dmai_EOK;
    BufTab_Handle            hBufTab = hDisplay->hBufTab;
    struct fb_var_screeninfo varInfo;
    struct fb_fix_screeninfo fixInfo;

    if (hDisplay->fd != -1) {
        if (ioctl(hDisplay->fd, FBIOGET_FSCREENINFO, &fixInfo) == -1) {
            printf("Failed FBIOGET_FSCREENINFO (%s)\n", strerror(errno));
            ret = Dmai_EFAIL;
        }

        if (ioctl(hDisplay->fd, FBIOGET_VSCREENINFO, &varInfo) == -1) {
            printf("Failed ioctl FBIOGET_VSCREENINFO (%s)\n",
                      strerror(errno));
            ret =  Dmai_EFAIL;
        }

        if (hBufTab) {
            munmap(Buffer_getUserPtr(BufTab_getBuf(hBufTab, 0)),
                   fixInfo.line_length * varInfo.yres_virtual);

            free(hBufTab);
        }

        mySetDisplayBuffer(hDisplay, 0);

        close(hDisplay->fd);
    }

    free(hDisplay);

    return ret;
}



/******************************************************************************
 * myDisplay_fbdev_create
 ******************************************************************************/
Display_Handle myDisplay_fbdev_create(BufTab_Handle hBufTab, myDisplay_Attrs *attrs)
{
    BufferGfx_Attrs         gfxAttrs       = BufferGfx_Attrs_DEFAULT;
    struct fb_var_screeninfo varInfo;
    struct fb_fix_screeninfo fixInfo;
    Int                      displaySize;
    Int                      bufIdx;
    Int8                    *virtPtr;
    Int                      height, width;
    Display_Handle           hDisplay;
    Buffer_Handle            hBuf;
    int i,j;

    if (attrs == NULL) {
        printf("Must supply valid attrs\n");
        return NULL;
    }

    if (hBufTab != NULL) {
        printf("FBdev display does not accept user allocated buffers\n");
        return NULL;
    }

    hDisplay = calloc(1, sizeof(Display_Object));

    if (hDisplay == NULL) {
        printf("Failed to allocate space for Display Object\n");
        return NULL;
    }
            
    /* Disable Graphics Interface */
    if (_Display_enableDevice((Display_Attrs *)attrs, FALSE)< 0) {
            printf("Failed to Disable Graphics overlay\n");
            cleanup(hDisplay);
            return NULL;
    }            
    
    /* Setup sysfs variable */
    if (_Display_sysfsChange(&attrs->videoOutput, attrs->displayDevice,
                        &attrs->videoStd, &attrs->rotation) < 0) {
        printf("Failed to setup sysfs variables\n");
        return NULL;
    }

    /* Open video display device */
    hDisplay->fd = open(attrs->displayDevice, O_RDWR);

    if (hDisplay->fd == -1) {
        printf("Failed to open fb device %s (%s)\n", attrs->displayDevice,
                                                        strerror(errno));
        cleanup(hDisplay);
        return NULL;
    }

    if (ioctl(hDisplay->fd, FBIOGET_FSCREENINFO, &fixInfo) == -1) {
        printf("Failed FBIOGET_FSCREENINFO on %s (%s)\n",
                  attrs->displayDevice, strerror(errno));
        cleanup(hDisplay);
        return NULL;
    }
    if (ioctl(hDisplay->fd, FBIOGET_VSCREENINFO, &varInfo) == -1) {
        printf("Failed FBIOGET_VSCREENINFO on %s (%s)\n",
                  attrs->displayDevice, strerror(errno));
        cleanup(hDisplay);
        return NULL;
    }

    switch(attrs->videoStd) {
        case myVideoStd_CIF:
            width = VideoStd_CIF_WIDTH;
            height = VideoStd_CIF_HEIGHT;
            break;
        case myVideoStd_SIF_NTSC:
            width = VideoStd_SIF_WIDTH;
            height = VideoStd_SIF_NTSC_HEIGHT;
            break;
        case myVideoStd_SIF_PAL:
            width = VideoStd_SIF_WIDTH;
            height = VideoStd_SIF_PAL_HEIGHT;
            break;
        case myVideoStd_VGA:
            width = VideoStd_VGA_WIDTH;
            height = VideoStd_VGA_HEIGHT;
            break;
        case myVideoStd_D1_NTSC:
            width = VideoStd_D1_WIDTH;
            height = VideoStd_D1_NTSC_HEIGHT;
            break;
        case myVideoStd_D1_PAL:
            width = VideoStd_D1_WIDTH;
            height = VideoStd_D1_PAL_HEIGHT;
            break;
        case myVideoStd_480P:
            width = VideoStd_480P_WIDTH;
            height = VideoStd_480P_HEIGHT;
            break;
        case myVideoStd_576P:
            width = VideoStd_576P_WIDTH;
            height = VideoStd_576P_HEIGHT;
            break;
        case myVideoStd_720P_60:
            width = VideoStd_720P_WIDTH;
            height = VideoStd_720P_HEIGHT;
            break;
        case myVideoStd_480_272:
            width = 480;
            height = 272;
            break;
        default:
            printf("Unknown video standard %d\n", attrs->videoStd);
            cleanup(hDisplay);
            return NULL;
    }

    
// Define rotation for OMAP3530
    if (attrs->rotation == 0 || attrs->rotation == 90 
            || attrs->rotation == 180 || attrs->rotation == 270){
        varInfo.rotate = (Int)(attrs->rotation/90);
    }else{
        printf("Invalid Rotation Value used: %d\n", attrs->rotation);
        cleanup(hDisplay);
        return NULL;
    }

    // update from DMAI -- dmai doesn't handle rotation correctly
    if (attrs->rotation == 90 || attrs->rotation == 270){
	    varInfo.xres            = width;
	    varInfo.yres            = height;
	    varInfo.xres_virtual    = width;
	    varInfo.yres_virtual    = width * attrs->numBufs;
    } else {
	    varInfo.xres            = height;
            height = width;
            width = varInfo.xres;
	    varInfo.yres            = height;
	    varInfo.xres_virtual    = width;
	    varInfo.yres_virtual    = height * attrs->numBufs;
    }


    switch (attrs->colorSpace) {

        case myColorSpace_RGB565:
            #if defined(Dmai_Device_omap3530)
            varInfo.red.length = 5;
            varInfo.green.length = 6;
            varInfo.blue.length = 5; 
            #endif
            gfxAttrs.colorSpace = ColorSpace_RGB565;
            break;

        case myColorSpace_UYVY:
            #if defined(Dmai_Device_omap3530)
            varInfo.nonstd  = OMAPFB_COLOR_YUV422;
            #endif
            gfxAttrs.colorSpace = ColorSpace_UYVY;
            break;

        case myColorSpace_ARGB:
	    varInfo.red.length = 8;
	    varInfo.green.length = 8;
	    varInfo.blue.length = 8;
	    varInfo.transp.length = 8; 
	    varInfo.red.offset = 16;
	    varInfo.green.offset = 8;
	    varInfo.blue.offset = 0;
	    varInfo.transp.offset = 24;     
	    varInfo.bits_per_pixel = 32;
//  Just set color space to NOTSET so standard DMAI doesn't get confused
            gfxAttrs.colorSpace = ColorSpace_NOTSET;
	    break;

        default:
            printf("Unknown colorspace\n");
            cleanup(hDisplay);
            return NULL;
    }

    /* Set video display format */

    if (ioctl(hDisplay->fd, FBIOPUT_VSCREENINFO, &varInfo) == -1) {
        printf("Failed FBIOPUT_VSCREENINFO on %s (%s)\n",
                  attrs->displayDevice, strerror(errno));
        cleanup(hDisplay);
        return NULL;
    }


    if (varInfo.xres != width || varInfo.yres != height){
        printf("Failed to get %d buffer(s) with requested screen"
                  "size: %dx%d\n", attrs->numBufs, width, height);
        cleanup(hDisplay);
	printf("was returned xres = %d, yres = %d\n", varInfo.xres, varInfo.yres);
        return NULL;
    }


    //  note:  update from DMAI: need to reget fixed screen info because 
    //         linelength will change if rotation is applied
    if (ioctl(hDisplay->fd, FBIOGET_FSCREENINFO, &fixInfo) == -1) {
        printf("Failed FBIOGET_FSCREENINFO on %s (%s)\n",
                  attrs->displayDevice, strerror(errno));
        cleanup(hDisplay);
        return NULL;
    }


    /* Determine the size of the display buffers inside the device driver */
    // update from DMAI -- dmai doesn't handle rotation correctly

    if (varInfo.rotate == 1 || varInfo.rotate == 3){
    	displaySize = fixInfo.line_length * varInfo.xres;
    } else {
    	displaySize = fixInfo.line_length * varInfo.yres;
    }

    gfxAttrs.dim.width          = varInfo.xres;
    gfxAttrs.dim.height         = varInfo.yres;
    gfxAttrs.dim.lineLength     = fixInfo.line_length;

    gfxAttrs.bAttrs.reference   = TRUE;

    hBufTab = BufTab_create(attrs->numBufs, displaySize,
                            BufferGfx_getBufferAttrs(&gfxAttrs));

    if (hBufTab == NULL) {
        printf("Failed to allocate BufTab for display buffers\n");
        cleanup(hDisplay);
        return NULL;
    }

    hBuf = BufTab_getBuf(hBufTab, 0);

    Buffer_setNumBytesUsed(hBuf, varInfo.xres * varInfo.yres *
                                 varInfo.bits_per_pixel / 8);

    virtPtr = (Int8 *) mmap (NULL,
                             displaySize * attrs->numBufs,
                             PROT_READ | PROT_WRITE,
                             MAP_SHARED,
                             hDisplay->fd, 0);


    // update to DMAI for rotation
//    if ((varInfo.rotate == 1 || varInfo.rotate == 3) && attrs->numBufs > 1){
//    	virtPtr += fixInfo.line_length * (varInfo.xres - varInfo.yres) + displaySize;
//    } else if ((varInfo.rotate == 1 || varInfo.rotate == 3) && attrs->numBufs == 1){
//    	virtPtr += fixInfo.line_length * (varInfo.xres - varInfo.yres);
//    }
    

    if (virtPtr == MAP_FAILED) {
        printf("Failed mmap on %s (%s)\n", attrs->displayDevice,
                                              strerror(errno));
        cleanup(hDisplay);
        return NULL;
    }

    if (Buffer_setUserPtr(hBuf, virtPtr) < 0) {
        cleanup(hDisplay);
        return NULL;
    }

    if(attrs->colorSpace == myColorSpace_ARGB){
	for(i=0;i<varInfo.xres;i++){
	    for(j=0;j<varInfo.yres;j++){
		*(((unsigned int *) virtPtr) + j*fixInfo.line_length/4 + i ) = 0;
	    }
	}
    } else {
         _Dmai_blackFill(hBuf);
    }


    for (bufIdx=1; bufIdx < attrs->numBufs; bufIdx++) {
        hBuf = BufTab_getBuf(hBufTab, bufIdx);
        Buffer_setNumBytesUsed(hBuf, varInfo.xres * varInfo.yres *
                                     varInfo.bits_per_pixel / 8);


    if (varInfo.rotate == 1 || varInfo.rotate == 3){
//	    virtPtr += varInfo.xres * varInfo.bits_per_pixel / 8;
	virtPtr += varInfo.xres * varInfo.bits_per_pixel / 8 + (varInfo.xres-32) * fixInfo.line_length;
    } else {
            virtPtr = virtPtr + displaySize;
    }


        Buffer_setUserPtr(hBuf, virtPtr);
    
        if(attrs->colorSpace == myColorSpace_ARGB){
	    for(i=0;i<varInfo.xres;i++){
		for(j=0;j<varInfo.yres;j++){
		    *(((unsigned int *) virtPtr) + j*fixInfo.line_length/4 + i ) = 0;
		}
	    }
        } else {
             _Dmai_blackFill(hBuf);
        }

        printf("Display buffer %d mapped to %#lx \n",
                  bufIdx, (unsigned long) virtPtr);
    }

    /* Enable Graphics Interface */
    if (_Display_enableDevice((Display_Attrs *)attrs, TRUE)< 0) {
            printf("Failed to Enable Graphics overlay\n");
            cleanup(hDisplay);
            return NULL;
    }

    hDisplay->hBufTab = hBufTab;
    hDisplay->displayIdx = 0;
    hDisplay->workingIdx = attrs->numBufs > 1 ? 1 : 0;
    hDisplay->displayStd = Display_Std_FBDEV;

    if (mySetDisplayBuffer(hDisplay, hDisplay->displayIdx) < 0) {
        cleanup(hDisplay);
        return NULL;
    }

    return hDisplay;
}

/******************************************************************************
 * Display_fbdev_get
 ******************************************************************************/
Int myDisplay_fbdev_get(Display_Handle hDisplay, Buffer_Handle *hBufPtr)
{
    Int dummy =0;
    BufTab_Handle hBufTab = hDisplay->hBufTab;
//    Int32 numBufs;
//    numBufs = BufTab_getNumBufs(hBufTab);

//    assert(hDisplay);
    assert(hBufPtr);
//    hDisplay->displayIdx = (hDisplay->displayIdx + 1) % numBufs;
//    hDisplay->workingIdx = (hDisplay->workingIdx + 1) % numBufs;

    /* Wait for vertical sync */
    if (ioctl(hDisplay->fd, OMAPFB_WAITFORVSYNC, &dummy) == -1) {
        printf("Failed OMAPFB_WAITFORVSYNC (%s)\n", strerror(errno));
        return Dmai_EFAIL;
    }

    *hBufPtr = BufTab_getBuf(hBufTab, hDisplay->workingIdx);

    return Dmai_EOK;
}

/******************************************************************************
 * Display_fbdev_put
 ******************************************************************************/
Int myDisplay_fbdev_put(Display_Handle hDisplay, Buffer_Handle hBuf)
{
//    Int dummy =0;
    BufTab_Handle hBufTab = hDisplay->hBufTab;
    Int32 numBufs;
    numBufs = BufTab_getNumBufs(hBufTab);

    assert(hDisplay);
//    assert(hBufPtr);
    hDisplay->displayIdx = (hDisplay->displayIdx + 1) % numBufs;
    hDisplay->workingIdx = (hDisplay->workingIdx + 1) % numBufs;

    return mySetDisplayBuffer(hDisplay, hDisplay->displayIdx);
}



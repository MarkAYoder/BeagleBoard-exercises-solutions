/* =============================================================================================
 * DotProduct Test Code
 *
 * While it's probably not great form to implement this as a #include into main.c, it was the
 * easiest way to provide the code needed to test the dot-product routine. As with many library
 * calls, the hard part isn't calling the routine, rather, it's setting up all the data.
 *
 * ============================================================================================= */
{
#define HALF    2
#define WORD    4

    // define local variables
    int cnt   = COUNT;
    int rstat = 0;
    int i     = 0;

    // create local data initialization tables (with data coming from data.h)
    short ainit[COUNT] = {A_ARRAY};
    short xinit[COUNT] = {X_ARRAY};   

    // allocate pointers for data and results
    short *a;
    short *x;
    int *dotp;

    // allocate memory to pointers; allocate using 'contigAlloc' functions so that data is contiguous as required by DSP
    a     = Memory_contigAlloc( COUNT*HALF, 8 );
    x     = Memory_contigAlloc( COUNT*HALF, 8 );
    dotp  = Memory_contigAlloc( 3*WORD, 8 );

    // initialize data arrays
    for ( i = 0; i < COUNT; i++ )
    {
        a[i]     = ainit[i];
        x[i]     = xinit[i];
    }

    dotp[0] = 0;
    dotp[1] = 0;
    dotp[2] = R_RESULT;

    // print out first 16 values of arrays for debugging purposes
    DBG ("\n---------------------------------------------------------------------------------\n");
    DBG ("    First 16 values of 'a' and 'x' arrays, plus inital results variables\n");
    DBG ("--------------------------------------------------------------------------\n");
    DBG ("a = %d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d \n", a[0], a[1],a[2],a[3],a[4],a[5],a[6],a[7],a[8], a[9],a[10],a[11],a[12],a[13],a[14],a[15]);
    DBG ("x = %d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d \n", x[0], x[1],x[2],x[3],x[4],x[5],x[6],x[7],x[8], x[9],x[10],x[11],x[12],x[13],x[14],x[15]);
    DBG ("DSP = %d, ARM = %d, Reference = %d \n", dotp[0], dotp[1], dotp[2]);
    DBG ("--------------------------------------------------------------------------\n");

   // Calculate the dot-product by calling the C6Accel routine on the DSP
   DBG ("\tCalling DSP's dot-product routine ...\n");
   rstat = C6accel_DSP_dotprod( hC6, a, x, dotp, cnt );

   // Calculate the dot-product on the ARM (code taken from C6Accel library reference code)
   DBG ("\tCalculating the dot-product routine on the ARM ...\n");
   for (i = 0; i < cnt; i++)
   {                                 
       dotp[1] += a[i] * x[i];  
   }  

   // print out results
    DBG ("\n---------------------------------------------------------------------------------\n");
    DBG ("    Dot-Product Results\n");
    DBG ("--------------------------------------------------------------------------\n");

    DBG ("DSP result = %d \n", dotp[0]);
    DBG ("ARM result = %d \n", dotp[1]);
    DBG ("Reference  = %d \n", dotp[2]);
    DBG ("--------------------------------------------------------------------------\n\n");
}
// =============================================================================================



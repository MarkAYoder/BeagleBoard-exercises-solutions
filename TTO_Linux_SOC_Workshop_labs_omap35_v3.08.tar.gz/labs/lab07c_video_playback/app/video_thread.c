/*
 *  video_thread.c
 */

/* Standard Linux headers */
#include <stdio.h>                               // always include stdio.h
#include <stdlib.h>                              // always include stdlib.h
#include <string.h>                              // defines memset and memcpy methods
#include <unistd.h>                              // prototype for sleep()

/* Codec Engine headers */
#include <xdc/std.h>                             // xdc definitions. Must come 1st

/* DMAI headers */
#include <ti/sdo/dmai/Dmai.h>
#include <ti/sdo/dmai/Capture.h>
#include <ti/sdo/dmai/Display.h>
#include <ti/sdo/dmai/Buffer.h>
#include <ti/sdo/dmai/BufferGfx.h>

/* Application header files */
#include "debug.h"                               // DBG and ERR macros
#include "video_thread.h"                        // Video thread definitions

/* Align buffers to this cache line size (in bytes)*/
#define BUFSIZEALIGN        128

/* Input file */
#define INPUTFILE       "/tmp/video.raw"

/* Macro for clearing structures */
#define CLEAR(x) memset (&(x), 0, sizeof (x))

/* Numbers of video buffers needed */
#define NUM_CAPTURE_BUFS 3
#define NUM_DISPLAY_BUFS 2
#define NUM_DECODER_BUFS 3


/**************************************************************************
 * video_thread_fxn                                                       *
 **************************************************************************/
/*  input parameters:                                                    */
/*      void *envByRef       --  pointer to video_thread_env structure   */
/*                               as defined in video_thread.h            */
/*                                                                       */
/*          envByRef.quit    -- when quit != 0, thread will exit         */
/*          env->engineName -- string value specifying name of           */
/*                              engine configuration for Engine_open     */
/*                                                                       */
/*  return value:                                                        */
/*      void *     --  VIDEO_THREAD_SUCCESS or VIDEO_THREAD_FAILURE as   */
/*                     defined in video_thread.h                         */
/*************************************************************************/
void *video_thread_fxn( void *envByRef )
{
/*  Thread parameters and return value */
    video_thread_env *env    = envByRef;                     // see above
    void             *status = VIDEO_THREAD_SUCCESS;         // see above

/*  The levels of initialization for initMask */
#define OSDSETUPCOMPLETE         0x1
#define DISPLAYDEVICEINITIALIZED 0x2
#define INPUTFILEOPENED          0x4
    unsigned int initMask = 0x0;            // Used to only cleanup items that were init'ed

/*  File variables  */
    FILE	*inputFile     = NULL;   // Input file pointer for recorded raw video data
    int     captureSize    = 0;      // Size of input frame (from inputFile)

/*  Display variables */
    Display_Attrs     dAttrs = Display_Attrs_O3530_VID_DEFAULT;
    Display_Handle    hDisplay = NULL;
    Buffer_Handle     dBuf;

    BufferGfx_Attrs  gfxAttrs = BufferGfx_Attrs_DEFAULT;
    BufTab_Handle    hBufTabDisplay = NULL;
    Int32            bufSize;


/* Thread Create Phase -- secure and initialize resources */


    // Initialize the video inputFile (for reading recorded raw data from lab07b)
    // ******************************

    // Open input file for read
    if( ( inputFile = fopen( INPUTFILE, "r" ) ) == NULL )
    {
        ERR( "Failed to open raw video input file %s\n", INPUTFILE );
        status = VIDEO_THREAD_FAILURE;
        goto cleanup;
    }

    DBG( "Opened file %s with FILE pointer %p\n", INPUTFILE, inputFile );

    // Record that video input file was opened in initialization bitmask
    initMask |= INPUTFILEOPENED;

/* Setup Display */

    /* Set output standard to match input */
    // Read video standard from file. We use a simplistic approach of writing
    //      in the enumerated value, assumes capture and playback app agree
    if( fread( &dAttrs.videoStd, 4, 1, inputFile ) < 1 )
    {
        printf( "Failed to read video standard from input file\n" );
        goto cleanup;
    }

    dAttrs.numBufs = NUM_DISPLAY_BUFS;
    dAttrs.rotation = 90;

    // Read size of next video frame to be read from video file
    if( fread( &captureSize, 4, 1, inputFile ) < 1 )
    {
        printf( "Failed to read capture size from input file\n" );
        goto cleanup;
    }

    printf( "Frame capture size of %d bytes\n", captureSize );

    bufSize = captureSize;

    /* Create a table of buffers to use with the display driver  */
    hBufTabDisplay = BufTab_create( NUM_DISPLAY_BUFS, 
                                    bufSize,
                                    BufferGfx_getBufferAttrs( &gfxAttrs ) );

    if ( hBufTabDisplay == NULL ) 
    {
        printf( "Failed to allocate contiguous buffers\n" );
        goto cleanup;
    }

    /* Create the display driver instance */
    hDisplay = Display_create( hBufTabDisplay, &dAttrs );
    if( hDisplay == NULL )
    {
        ERR( "Failed to open handle to Display driver in video_thread_fxn\n" );
        status = VIDEO_THREAD_FAILURE;
        goto cleanup;
    }

    /* Record that display device was opened in initialization bitmask */
    initMask |= DISPLAYDEVICEINITIALIZED;


/* Thread Execute Phase -- perform I/O and processing */

    DBG( "Entering video_thread_fxn processing loop.\n" );

    while ( !env->quit )
    {
        Display_get( hDisplay, &dBuf );

        // Read raw video data from inputFile
        if( fread( Buffer_getUserPtr( dBuf ), 1, captureSize, inputFile ) < captureSize )
            break;

        Display_put( hDisplay, dBuf );
    }

    // Since we can only fit a few frames in /tmp (RAM) pause at end before shutting off display
    sleep( 5 );

cleanup:
    /* Thread Delete Phase -- free resources no longer needed by thread */

    DBG( "Exited video_thread_fxn processing loop\n" );
    DBG( "\tStarting video thread cleanup to return resources to system\n" );

    /* Use the initMask to only free resources that were allocated     */
    /* Nothing to be done for mixer device, it was closed after init   */

    /* Close input file */
    if( initMask & INPUTFILEOPENED )
    {
        fclose( inputFile );
    }

    /* Close video display device */ 
    if ( initMask & DISPLAYDEVICEINITIALIZED ) 
    {
        Display_delete( hDisplay );
    }

    /* Return the status of the thread execution */
    DBG( "\tVideo thread cleanup complete. Exiting video_thread_fxn.\n" );
    return (void *)status;
}

